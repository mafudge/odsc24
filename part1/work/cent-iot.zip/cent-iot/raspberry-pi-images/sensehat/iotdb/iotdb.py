import requests
import json
import CloudFlare
import argparse
from prettytable import PrettyTable
import platform
import io
import os
import logging

email = 'mafudge@syr.edu'
api_key = '942fda8c3c8a6b768d71828b958eb64b70308'
domain = 'ischool-iot.net'
zone_id = '2ddeea087c44955831b30e8ad5138ecd'
proxied = False
logging.basicConfig(level=logging.INFO)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('action', type=str, help='What operation? (register, unregister, list, hostinfo)')
    parser.add_argument('--hardware', type=str, default='none', help='hardware sensehat, sensorboard')
    parser.add_argument('--location', type=str, default='none', help='What is the IP address of the host?')
    args = parser.parse_args()
    info = get_sysinfo(args.hardware,args.location)
    if args.action == 'register':
        register(info)
    if args.action == 'unregister':
        unregister(info)
    if args.action == 'list':
        list_records()
    if args.action == 'hostinfo':
        host_info(info)
    exit(0)

#--------------------Register--------------------
def register(info):
    if not check_name(info['hostname']):
        delete_records(info['hostname'])
        add_a_record(info['hostname'], info['ip'])
        add_txt_record(info['hostname'],info)
        logging.info(f'Host Hostname {info["hostname"]} Registered !!!')
    else:
        #current_ip = get_ip()
        logging.error(f'Hostname {info["hostname"]} already registered !!!!')


#--------------------Hostinfo--------------------
def host_info(info):
    logging.info("Host Information: {info}")


#--------------------Unregister--------------------
def unregister(info):
    delete_records(info['hostname'])
    logging.info(f'Host Hostname {info["hostname"]} Unregistered !!!')


#--------------------List--------------------
def list_records():
    cf = CloudFlare.CloudFlare(email, api_key, domain, proxied)
    
    # request the DNS records from that zone
    try:
       dns_records = cf.zones.dns_records.get(zone_id)
    except CloudFlare.exceptions.CloudFlareAPIError as e:
        exit('/zones/dns_records.get %d %s - api call failed' % (e, e))

    read_dns = PrettyTable()
    # print all the DNS records for that zone
    read_dns.field_names = ['Type', 'Name', 'Content']

    for dns_record in dns_records:
        r_name = dns_record['name']
        r_type = dns_record['type']
        r_value = dns_record['content']
        #r_id = dns_record['id']
        if r_type == 'A' or r_type == 'TXT':
            read_dns.add_row([r_type, r_name, r_value])

    print(read_dns)


#--------------------Helper Functions--------------------
def get_ip():
    url = 'http://ip.42.pl/raw'
    response = requests.get(url)
    return str(response.text)

def get_model():
    if os.name == 'posix':
        try:
            with io.open('/sys/firmware/devicetree/base/model','r') as model:
                return model.read().strip()
        except FileNotFoundError:
            pass 

    return "none"

def get_hardware():
    hw = 'none'

def get_sysinfo(hardware, location):
    uname = platform.uname()
    return {
        'arch' : uname.machine.lower(),
        'hostname' : uname.node.lower(),
        'os' : uname.system.lower(),
        'ip' : get_ip(),
        'model' : get_model(),
        'hardware' : hardware,
        'location' : location
    }


def add_a_record(hostname, current_ip):
    requests.post(
    'https://api.cloudflare.com/client/v4/zones/{}/dns_records/'.format(zone_id),
    json={
        'type': 'A',
        'name': hostname,
        'content': current_ip,
        'proxied': False
    },
    headers={
        'X-Auth-Key': api_key,
        'X-Auth-Email': email
    })


def delete_records(hostname):
    cf = CloudFlare.CloudFlare(email, api_key, domain, proxied)
    fqdn = f"{hostname}.{domain}"
    try:
        dns_records = cf.zones.dns_records.get(zone_id)
    except CloudFlare.exceptions.CloudFlareAPIError as e:
        exit('/zones/dns_records.get %d %s - api call failed' % (e, e))

    for dns_record in dns_records:
        if dns_record['name'] == fqdn:
            cf.zones.dns_records.delete(zone_id, dns_record['id'])


def add_txt_record(hostname, data):
    requests.post(
    'https://api.cloudflare.com/client/v4/zones/{}/dns_records/'.format(zone_id),
    json={
        'type': 'TXT',
        'name': hostname,
        'content': str(data),
        'proxied': False
    },
    headers={
        'X-Auth-Key': api_key,
        'X-Auth-Email': email
    })



def check_name(name):
    cf = CloudFlare.CloudFlare(email, api_key, domain, proxied)
    try:
        dns_records = cf.zones.dns_records.get(zone_id)
    except CloudFlare.exceptions.CloudFlareAPIError as e:
        exit('/zones/dns_records.get %d %s - api call failed' % (e, e))
    for dns_record in dns_records:
        r_name = dns_record['name']
        #r_value = dns_record['content']
        #r_id = dns_record['id']
        #r_type = dns_record['type']
        if r_name == name:
            return True


def get_record(name, ip):
    cf = CloudFlare.CloudFlare(email, api_key, domain, proxied)

    try:
        dns_records = cf.zones.dns_records.get(zone_id)
    except CloudFlare.exceptions.CloudFlareAPIError as e:
        exit('/zones/dns_records.get %d %s - api call failed' % (e, e))

    for dns_record in dns_records:
        r_name = dns_record['name']
        r_value = dns_record['content']
        r_id = dns_record['id']
        r_type = dns_record['type']

        if (r_name == name and r_value == ip):
            return r_id
   


# --------------------main-------------------

if __name__ == '__main__':
    main()