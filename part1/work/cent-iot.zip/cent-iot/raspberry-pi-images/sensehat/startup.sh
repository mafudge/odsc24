#!/bin/bash

# ADDITIONAL_APT_PACKAGES="wget curl foo bar"
# ADDITIONAL_PIP_PACKAGES="numpy pandas"
# GIT_REPO_URL="https://path.to.clone.repo"
# PYTHON_SCRIPT="something.py -arg1=a -arg2=b"

GR='\033[1;32m'
RD='\033[0;31m'
NC='\033[0m'

if [[ -z ADDITIONAL_APT_PACKAGES || ! -v ADDITIONAL_APT_PACKAGES ]]; then
    echo -e "${GR}[startup.sh]:${NC} No additional apt packages specified."
else
    echo -e "${GR}[startup.sh]:${NC} installing apt packages: ${ADDITIONAL_APT_PACKAGES}"
    /usr/bin/apt-get install -y ${ADDITIONAL_APT_PACKAGES}
fi

if [[ -z ADDITIONAL_PIP_PACKAGES || ! -v ADDITIONAL_PIP_PACKAGES ]]; then
    echo -e "${GR}[startup.sh]:${NC} No additional Python packages specified."
else
    echo -e "${GR}[startup.sh]:${NC} installing Python packages: ${ADDITIONAL_PIP_PACKAGES}"
    /usr/bin/pip3 install ${ADDITIONAL_PIP_PACKAGES}
fi

if [[ -z GIT_REPO_URL || ! -v GIT_REPO_URL ]]; then
    echo -e "${RD}[startup.sh]:${NC} ERROR! A git repository is required! Please set GIT_REPO_URL"    
else
    echo -e "${GR}[startup.sh]:${NC} Cloning git repository: ${GIT_REPO_URL}"    
    /usr/bin/git clone ${GIT_REPO_URL} .

    if [[ -z PYTHON_SCRIPT || ! -v PYTHON_SCRIPT ]]; then
        echo -e "${RD}[startup.sh]:${NC} ERROR! A startup Python script is required! Please set PYTHON_SCRIPT"    
    else
        echo -e "${GR}[startup.sh]:${NC} Running Python script: ${PYTHON_SCRIPT}"
        /usr/bin/python3 ${PYTHON_SCRIPT}
    fi
fi



