from time import sleep
from sense_hat import SenseHat

try:
    sense = SenseHat()
    message="Hello, World!"
    while True:
        print(message)
        sense.show_message(message)
        sleep(5)

except OSError:
    print("No SenseHat Deteceted!")
except KeyboardInterrupt:
    sense.clear()