import sys
import os
import logging
import json
import hashlib
import requests

logging.basicConfig(level=logging.INFO)

funcEndpoint = "http://optiplex790.home.michaelfudge.com:31007/stream"

def help(quit=True):
    print("USAGE: funcitup notebookfile.ipynb")
    if quit: exit(1)

def error(message, quit=False ):
    logging.error(f"MESSAGE: {message}")
    if quit: exit(1)

def currentUser(overrideUser=""):
    if overrideUser == "":
        user = os.environ["JUPYTERHUB_USER"].strip()
        assert user in os.environ["JUPYTERHUB_SERVICE_PREFIX"]
        assert user in os.environ["JUPYTERHUB_CLIENT_ID"]
        assert user in os.environ["JUPYTERHUB_ACTIVITY_URL"]
        return user
    else:
        return overrideUser

def cloudFunctionName(user, notebook):
    SALT = "JNW$MX#%ICV^#VQ"
    base = os.path.basename(notebook).rstrip(".ipynb")
    data = f"{user}{SALT}{notebook}"
    key = hashlib.md5(data.encode()).hexdigest()[:8]
    return f"{user}-{base}-{key}".lower()


def getRequirements(stringlist):
    return [row.split(" ")[-1].strip() for row in stringlist if row.startswith("!pip")]     

class Notebook(object):
    
    def __init__(self, fileName):
        with open(fileName,"r") as f:
            self.__content = json.load(f)

    @property
    def content(self):
        return self.__content
            
    def CellCount(self):
        return len(self.__content["cells"])
    
    def CodeCells(self):
        return [ cell for cell in self.__content["cells"] if cell["cell_type"]=="code"]
    
    def CodeCellCount(self):
        return len(self.CodeCells())

    def GetCodeInCell(self, index=0):
        return self.CodeCells()[index]["source"]

    
    
if __name__=='__main__':
    args = sys.argv
    if len(args) <= 1:
        help(quit=True)
    notebookfile = args[1]
    if not os.path.exists(notebookfile):
        error(f"Unable to locate notebook file {notebookfile} -- do you have the right filename?", quit=True)

    try:
        user = currentUser("mafudge")
    except (KeyError,AssertionError) as e:
        error(f"Unable determine your username -- are you in the Jupyterhub environment?", quit=True) 
    
    funcname = cloudFunctionName(user, notebookfile)
    nb = Notebook(notebookfile)
    codeCellCount = nb.CodeCellCount()
    if codeCellCount != 2:
        error(f"Your notebook {notebookfile} as an incorrect code cell count. There {codeCellCount} cells but there should be 2.", quit=True) 
    
    requirementsCell = False
    handlerCell = False 
    handlerCode = []
    requirements = []
    
    for i in range(codeCellCount):
        code = nb.GetCodeInCell(i)
        if "#requirements" in code[0]:
            requirementsCell = True
            requirements = getRequirements(code)
        elif "#handler" in code[0]:
            handlerCell = True
            handlerCode = code


    logging.info(f"USER:               {user}")
    logging.info(f"NOTEBOOK FILE:      {notebookfile}")
    logging.info(f"FUNCTION:           {funcname}")
    logging.info(f"CODE CELL COUNT:    {codeCellCount}")
    logging.info(f"#requirements CELL: {requirementsCell}")
    logging.info(f"#handler CELL:      {handlerCell}")
    logging.info(f"REQUIREMENTS:       {','.join(requirements)}")

    print(f"FUNC-A-FYING YOUR CODE....HERE IS THE OUTPUT:")
    payload = { 'function' : funcname, 'requirements' : requirements, 'handler' : handlerCode }
    r = requests.post(funcEndpoint, json = payload, stream=True)
    for line in r.iter_lines(chunk_size=1):
        if line:
            decoded_line = line.decode('utf-8')
            print(decoded_line)