#!/bin/bash
pip3 install -r requirements.txt
curl -sLS https://get.arkade.dev | sudo sh
arkade get faas-cli
sudo mv /home/ubuntu/.arkade/bin/faas-cli /usr/local/bin/
mkdir faas || true
cd faas 
FAAS_PASSWORD=$(kubectl get secret -n openfaas basic-auth -o jsonpath="{.data.basic-auth-password}" | base64 --decode; echo)
echo -n $FAAS_PASSWORD | faas-cli login --gateway http://openfaas.home.michaelfudge.com --username admin --password-stdin
faas-cli template store pull python3-flask-debian
cat ~/.docker_password | docker login --username mafudge --password-stdin
