import flask
import subprocess
import os 
import apputils

from flask import Flask, request, jsonify, Response
import time

from flask.helpers import stream_with_context 

FAAS_FOLDER = "faas"
FAAS_URL = "http://openfaas.home.michaelfudge.com"
IMAGE_PREFIX = "mafudge"

def faas_cli(args = []):
    faascmd = ["faas-cli"]
    cmd = faascmd + args 
    result = subprocess.run(cmd,cwd=FAAS_FOLDER, stdout=subprocess.PIPE)
    return result.stdout.decode() 

app = Flask(__name__)


@app.route("/stream", methods=["POST"])
def funcitup():

    def generate():
        if not os.path.exists(FAAS_FOLDER):
            os.makedirs(FAAS_FOLDER)
        yield f"HEADERS: {flask.request.headers}\n"
        if flask.request.is_json:
            try:
                data = flask.request.get_json(silent=True)
                project_name = data['function']
                project_file = f"{project_name}.yml"
                yield f"PROJECT NAME : {project_name}\n"
                yield f"REQUIREMENTS  : {data['requirements']}\n"
                yield f"LINES OF HANDLER CODE  : {len(data['handler'])}\n"
            except KeyError:
                yield "ERROR: Invalid Payload!\n"
                return    
        else:
            yield "ERROR: Invalid Payload!\n"
            return 

        yield "******************** CREATE PROJECT ********************"
        newfunc = ["-g", FAAS_URL, "new", project_name, "--lang", "python3-flask-debian"]
        result = faas_cli(newfunc)
        yield f"OUTPUT:\n{result}\n"

        newimage = apputils.updateImageConfig(FAAS_FOLDER, project_name, IMAGE_PREFIX)
        requirements = apputils.writeRequirementsTxt(FAAS_FOLDER, project_name, data['requirements'])
        code = apputils.writeHandlerPy(FAAS_FOLDER, project_name,data['handler'])

        yield "******************** BUILDING PROJECT ********************"
        build = ["build", "-f", project_file]
        result = faas_cli(build)
        yield f"OUTPUT:\n{result}\n"

        yield "******************** PUSHING PROJECT ********************"
        build = ["push", "-f", project_file]
        result = faas_cli(build)
        yield f"OUTPUT:\n{result}\n"
        
        yield "******************** DEPLOY PROJECT ********************"
        build = ["deploy", "-g", FAAS_URL, "-f", project_file ]
        result = faas_cli(build)
        yield f"OUTPUT:\n{result}\n"



    return app.response_class(stream_with_context(generate()))

# @app.route("/", methods=["POST"])
# def funcitup():
#     print(flask.request.headers)
#     if flask.request.is_json:
#         data = flask.request.get_json(silent=True)
#     else:
#         print("Invalid Format!")
#     result = subprocess.run(["cmd","/C","DIR"], stdout=subprocess.PIPE)
#     print(result.stdout)
#     return jsonify(data)

@app.route("/foo", methods=["POST"])
def foo():
    def generate():
        for i in range(5):
            time.sleep(1)
            yield f"{i}\n"
    return Response(generate())
