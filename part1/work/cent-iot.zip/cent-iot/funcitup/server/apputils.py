import os 
import yaml

from yaml.loader import SafeLoader

def updateImageConfig(folder, projectName, imagePrefix):
    # Open the file and load the file
    yamlFile = f"{folder}/{projectName}.yml"
    with open(yamlFile) as f:
        data = yaml.load(f, Loader=SafeLoader)

    image_name = data["functions"][projectName]["image"]
    if not image_name.startswith(f"{imagePrefix}/"):
        image_name = f"{imagePrefix}/{image_name}"

    with open(yamlFile,"w") as f:
        yaml.dump(data,f)

    return image_name

def writeRequirementsTxt(folder, projectName, requirementsList):
    requirements_file = f"{folder}/{projectName}/requirements.txt"
    buffer = "\n".join(requirementsList)
    with open(requirements_file,"w") as f:
        f.write(buffer)

    return buffer

def writeHandlerPy(folder, projectName, codeList):
    code_file = f"{folder}/{projectName}/handler.py"
    buffer = "\n".join(codeList)
    with open(code_file,"w") as f:
        f.write(buffer)

    return buffer


if __name__== '__main__':
    folder ="faas"
    project = "testing"
    image_prefix = "mafudge"
    requirements_list = ["pandas", "requests"]
    newimage = updateImageConfig(folder, project, image_prefix)
    requirements = writeRequirementsTxt(folder, project, requirements_list)
    assert newimage == f"{image_prefix}/{project}:latest"
    assert requirements == "\n".join(requirements_list)