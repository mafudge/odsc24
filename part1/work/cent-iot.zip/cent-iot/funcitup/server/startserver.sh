#!/bin/bash
python3 -m flask run --port 31007 --host 0.0.0.0