# Func-It-Up!


Let's convert your jupyter notebook into an openfass function!


## Usage

funcitup {notebook.ipynb}



## Architecture


funcitup client - runs in the jupyterhub environment. sends data to a funcitup server via http

funcitup server (can't be in docker because it needs to built with docker - needs to be a vm)
- flask app recievea the http request with json payload
- faas-cli creates new {project} with name using the dict key "function"
- requirements.txt generated from key "requirements"
- handler.py generated from key "handler"
- then we issue 
    - $ faas-cli build -f {project}.yml
    - $ faas-cli push-f {project}.yml
    - $ faas-cli deploy -f {project}.yml
- the URL is output back to the end user should be http://openfaasdomain/functions/{project}



# NOTES:

Open Faas Commands


Inputs

$ faas-cli create {project} --lang=python
$ make requirements.txt
$ make handler.py
$ faas-cli build -f {project}.yml
$ faas-cli push-f {project}.yml
$ faas-cli deploy -f {project}.yml
