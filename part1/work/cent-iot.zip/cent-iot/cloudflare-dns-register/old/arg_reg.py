import requests
import json
import CloudFlare
import argparse
from prettytable import PrettyTable

email = 'mafudge@syr.edu'
api_key = '942fda8c3c8a6b768d71828b958eb64b70308'
domain = 'ischool-iot.net'
zone_id = '2ddeea087c44955831b30e8ad5138ecd'
proxied = False

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('action', type=str, help='What operation? (register, unregister, list)')
    parser.add_argument('--hostname', type=str, help='What is the hostname?')
    parser.add_argument('--ip', type=str, default=get_ip(), help='What is the IP address of the host?')
    args = parser.parse_args()

    if args.action == 'register':
        register(args.hostname, args.ip)
    if args.action == 'unregister':
        unregister(args.hostname, args.ip)
    if args.action == 'list':
        dns_read()

#--------------------Register--------------------
def get_ip():
    url = 'http://ip.42.pl/raw'
    response = requests.get(url)
    return str(response.text)

def add_record(hostname, current_ip):
    requests.post(
    'https://api.cloudflare.com/client/v4/zones/{}/dns_records/'.format(zone_id),
    json={
        'type': 'A',
        'name': hostname,
        'content': current_ip,
        'proxied': False
    },
    headers={
        'X-Auth-Key': api_key,
        'X-Auth-Email': email
    })

def check_name(name):
    cf = CloudFlare.CloudFlare(email, api_key, domain, proxied)
    try:
        dns_records = cf.zones.dns_records.get(zone_id)
    except CloudFlare.exceptions.CloudFlareAPIError as e:
        exit('/zones/dns_records.get %d %s - api call failed' % (e, e))
    for dns_record in dns_records:
        r_name = dns_record['name']
        #r_value = dns_record['content']
        #r_id = dns_record['id']
        #r_type = dns_record['type']
        if r_name == name:
            print('Hostname already exists !!!!')
            return True

def register(hostname, ip):
    name = hostname + '.' + domain
    if check_name(name):
        hostname = input('Enter a new hostname to be registered: ')
        register(hostname, ip)
    else:
        #current_ip = get_ip()
        add_record(hostname, ip)
        print('Host Registered !!!')
    exit(0)

#--------------------Unregister--------------------
def get_record(name, ip):
    cf = CloudFlare.CloudFlare(email, api_key, domain, proxied)

    try:
        dns_records = cf.zones.dns_records.get(zone_id)
    except CloudFlare.exceptions.CloudFlareAPIError as e:
        exit('/zones/dns_records.get %d %s - api call failed' % (e, e))

    for dns_record in dns_records:
        r_name = dns_record['name']
        r_value = dns_record['content']
        r_id = dns_record['id']
        #r_type = dns_record['type']

        if (r_name == name and r_value == ip):
            return r_id
    
def delete(name, record_id):
    cf = CloudFlare.CloudFlare(email, api_key, domain, proxied)

    try:
        cf.zones.dns_records.delete(zone_id, record_id)
        print('Host Unregistered !!!')
    except CloudFlare.exceptions.CloudFlareAPIError as e:
        exit('/zones.dns_records.delete %s - %d %s - api call failed' % (name, e, e))

    exit(0)

def unregister(name, ip):
    dns_name = name + '.' + domain
    record = get_record(dns_name, ip)
    delete(dns_name, record)

#--------------------List--------------------
def dns_read():
    cf = CloudFlare.CloudFlare(email, api_key, domain, proxied)
    
    # request the DNS records from that zone
    try:
       dns_records = cf.zones.dns_records.get(zone_id)
    except CloudFlare.exceptions.CloudFlareAPIError as e:
        exit('/zones/dns_records.get %d %s - api call failed' % (e, e))

    read_dns = PrettyTable()
    # print all the DNS records for that zone
    read_dns.field_names = ['Type', 'Name', 'Content']
    #print('\t', 'Type', '\t', 'Name', '\t', 'Content')

    for dns_record in dns_records:
        r_name = dns_record['name']
        r_type = dns_record['type']
        r_value = dns_record['content']
        #r_id = dns_record['id']
        if r_type == 'A':
            read_dns.add_row([r_type, r_name, r_value])

    print(read_dns)
    exit(0)

if __name__ == '__main__':
    main()