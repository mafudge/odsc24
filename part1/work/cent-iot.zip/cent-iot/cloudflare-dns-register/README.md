# cloudflare-dns-register

Uses the cloudflare DNS API to register hosts on the `ischool-iot.net` network.


## Usage from Command Line 

`register.py --auto`  registers the device IP and hostname, creating an `A` record.
`register.py --list`  lists all the `A` records for `ischool-iot.net` 