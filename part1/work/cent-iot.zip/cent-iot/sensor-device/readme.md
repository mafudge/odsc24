# IoT Sensor Device

Code for the actual sensor device.

includes 

`iotdevice` the python package for the device. see readme.md therein for details.
`tests.py` run tests on the `iotdevice` package



