#!/bin/bash
if pgrep -x "python3" > /dev/null
then
	echo "Diagnostics Already Running"
else
	/usr/bin/python3 /home/pi/git/sensor-device/diagnostics.py
fi

