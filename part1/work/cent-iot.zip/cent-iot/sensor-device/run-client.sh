#!/bin/bash
export MQTT_BROKER=nas.home.michaelfudge.com
export MQTT_PORT=1883
export DELAY_IN_SEC=30
export MQTT_DATA_TOPIC=cent/iot/livinglab/data
export MQTT_CMD_TOPIC=cent/iot/livinglab/cmd
if pgrep -x  "python3" > /dev/null
then 
	echo "Client Already Running"
else
	/usr/bin/python3 /home/pi/git/sensor-device/client.py
fi
