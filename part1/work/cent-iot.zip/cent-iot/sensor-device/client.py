import paho.mqtt.client as mqtt
import os
import logging 
import sys
from time import sleep
from iotdevice import device
from retrying import retry
import json
from datetime import datetime 

sleep( )

logging.basicConfig(format='%(levelname)s: %(asctime)s => %(message)s', level=logging.INFO, stream=sys.stdout)


if __name__=='__main__':

    broker= os.environ.get("MQTT_BROKER","nas.home.michaelfudge.com")
    port = int(os.environ.get("MQTT_PORT","1883"))
    delay_in_sec = int(os.environ.get("DELAY_IN_SEC", "30"))
    data_topic = os.environ.get("MQTT_DATA_TOPIC", "cent/iot/livinglab/data")
    cmd_topic = os.environ.get("MQTT_CMD_TOPIC","cent/iot/livinglab/cmd")

    dev = device.IoTDevice()

    logging.info(f"MQTT_BROKER={broker}")
    logging.info(f"MQTT_PORT={port}")
    logging.info(f"DELAY_IN_SEC={delay_in_sec}")
    logging.info(f"MQTT_DATA_TOPIC={data_topic}")
    logging.info(f"MQTT_CMD_TOPIC={cmd_topic}")
    
    def on_connect(client, userdata, flags, rc):
        logging.info(f"ON CONNECT: {client._host}:{client._port} data={userdata} {mqtt.connack_string(rc)}")

    def on_subscribe(client, userdata, mid, granted_qos):
        logging.info(f"ON SUBSCRIBE: {client._host}:{client._port} data={userdata}")

    def on_publish(client, userdata, mid):
        logging.info(f"ON PUBLISH: {client._host}:{client._port} data={userdata}")

    def on_message(client, userdata, message):
        data = json.loads(message.payload.decode('utf-8'))
        logging.info(f"ON MESSAGE:   {client._host}:{client._port} topic={message.topic} message={data} QoS={message.qos}")
        #TODO parse message

    try:
        client = mqtt.Client()                    
        client.on_connect = on_connect
        client.on_subscribe = on_subscribe
        client.on_publish = on_publish
        client.on_message = on_message
        client.connect(broker,port)
        client.loop_start()

        client.subscribe(cmd_topic)

        leds = dev.LEDGrid.Names()
        i = 0
        while True:
            sleep(delay_in_sec)
            dev.LEDGrid.Blink(led=leds[i], on=0.05, off=0.05)
            sensor_data = dev.ReadAll()
            current = datetime.now()
            sensor_data['timestamp'] = current.now().isoformat()
            sensor_data['timestamp_utc'] = current.utcnow().isoformat()
            logging.info(f"SENSOR DATA: {sensor_data}")
            client.publish(data_topic, json.dumps(sensor_data))
            dev.LEDGrid.Off(led=leds[i])
            i = 0 if i==len(leds)-1 else i+1

    except KeyboardInterrupt as e:
         client.loop_stop()
         client.disconnect()
         logging.info(f"{e}")
