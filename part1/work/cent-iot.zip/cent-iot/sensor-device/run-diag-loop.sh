#!/bin/bash
counter=1000
while  [ $counter -gt 0 ]
do
	echo $counter
	sleep 5
	if pgrep -x "python3" > /dev/null
	then
		echo "Diagnostics Already Running"
	else
		/usr/bin/python3 /home/pi/git/sensor-device/diagnostics.py
	fi
	counter=$(( $counter - 1 ))
done

