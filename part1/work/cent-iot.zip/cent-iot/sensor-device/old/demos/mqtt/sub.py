import paho.mqtt.client as mqtt
import time

def on_subscribe(client, obj, mid, granted_qos):
    print("Subscribed: " + str(mid) + " " + str(granted_qos))

def on_log(client, obj, level, string):
    print(string)

def on_message(client, obj, msg):
    print(msg.topic+" "+str(msg.qos)+" "+str(msg.payload))

if __name__ == '__main__':

    try:

        MQTT_HOST = '169.254.177.61' #'broker.hivemq.com'
        TOPIC = '/demo/pubsub'
        INTERVAL = 3 # Every 3 seconds
        counter = 0
        next_reading = time.time() 

        client = mqtt.Client()
        client.connect(MQTT_HOST, 1883,60)
        client.on_subscribe = on_subscribe
        client.on_message = on_message
        # cut down on the noise... disable
        #client.on_log = on_log
        client.subscribe(TOPIC,2)
        client.loop_forever()

    except KeyboardInterrupt:
        pass 

    finally:
        client.loop_stop()
        client.disconnect()
