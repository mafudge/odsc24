import paho.mqtt.client as mqtt
import time

if __name__ == '__main__':

    try:

        MQTT_HOST = '169.254.177.61' # 'broker.hivemq.com'
        TOPIC = '/demo/pubsub'
        INTERVAL = 3 # Every 3 seconds
        counter = 0
        next_reading = time.time() 

        client = mqtt.Client()
        client.connect(MQTT_HOST, 1883, 60)
        client.loop_start()

        while True:

            # Send a Message
            counter +=1
            data = "DATA {0}: The Time is now {1}.".format(counter, time.time())
            print("PUBLISH", data, "TO TOPIC", TOPIC)
            client.publish(TOPIC,data,False)

            # Is it time to poll again?
            next_reading += INTERVAL
            sleep_time = next_reading-time.time()
            if sleep_time > 0:
                time.sleep(sleep_time)
    except KeyboardInterrupt:
        pass 

    finally:
        client.loop_stop()
        client.disconnect()
