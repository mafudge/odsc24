import os
import time
import math 
from gpiozero import LED

class LEDGrid:

	valid_states = [ 'on', 'off', 'blink']
	leds = { 'red' : None, 'white' : None, 'blue' : None, 'green' : None, 'yellow' : None }
	led_states = { 'red' : 'off', 'white' : 'off', 'blue' : 'off', 'green' : 'off', 'yellow' : 'off' }
	default_pins = { 'red' : 5, 'white' : 6, 'blue' : 13, 'green' : 19, 'yellow' : 26 }


	def __init__(self, default_pins = default_pins, active_high=True):
		for key in self.leds.keys():
			self.leds[key] = LED( default_pins[key], active_high=active_high )
		self.AllOff()

	def On(self, led = 'all'):
		'''
		Turns on the led specified or use 'all' to turn them all on
		'''

		if led =='all':
			for key in self.leds.keys():
				self.leds[key].on()
				self.led_states[key] = 'on'
		elif led in self.leds.keys():
			self.leds[led].on()
			self.led_states[led] = 'on'
		else:
			pass

	def Off(self, led = 'all'):
		'''
		Turns off the led specified or use 'all' to turn them all off
		'''
		if led == 'all':
			for key in self.leds.keys():
				self.leds[key].off()
				self.led_states[key] = 'off'
		elif led in self.leds.keys():
			self.leds[led].off()
			self.led_states[led] = 'off'
		else:
			pass

	def Blink(self, led = 'all', on=0.5, off=0.5):
		'''
		Blinks the led specified or use 'all' to blink them all
		'''

		if led == 'all':
			for key in self.leds.keys():
				self.leds[key].blink()
				self.led_states[key] = 'blink'
		elif led in self.leds.keys():
			self.leds[led].blink(on_time=on, off_time=off)
			self.led_states[led] = 'blink'
		else:
			pass

	def AllOff(self):
		'''
		Turn off all LED's in the grid.
		'''
		self.Off()


	def Names(self):
		'''
		Returns a list of all the LED names ['white', 'red'] etc
		'''
		return list(self.leds.keys())

	def LEDs(self):
		'''
		Returns a dictionary of the actual gpiozero LED() objects, keyed by name e.g. 'red'
		'''
		return self.leds

	def Status(self):
		'''
		Returns a dictionary of the leds along with their current State
		'''
		return self.led_states

	def Pins(self):
		'''
		Returns a dict of led names and their corresponding GPIO pins on the Pi
		'''
		return self.default_pins

	def ValidStates(self):
		'''
		Returns a list of possible LED states ['on', 'off','blink']
		'''
		return self.valid_states


if __name__=='__main__':

	try:
		g = LEDGrid(active_high=True)
		g.AllOff()


		print("LEDS", g.LEDs())
		print("GPIO Pins",g.Pins())
		print("Valid States", g.ValidStates())
		print("LED Status",g.Status())

		n = 50
		x = 0
		while x < 1:		
			interval = abs(0.25 * math.sin(x *10))
			x += 0.05
			print("Blink on/off interval ", interval )
			g.Blink('white', on=interval, off=interval)
			time.sleep(0.25)
		

		'''
		
		print("Turning on:")
		for name in g.Names():
			print(name)
			g.On(name)
			print(g.LEDStatus())
			time.sleep(0.333)

		time.sleep(2)

		print("Turning Off:")
		for name in g.Names():
			print(name)
			g.Off(name)
			print(g.LEDStatus())
			time.sleep(0.333)

		time.sleep(2)

		print("Blinking:")
		for name in g.Names():
			print(name)
			g.Blink(name, 0.25, 0.25)
			print(g.LEDStatus())
			time.sleep(1)

		time.sleep(2)
		
		print(g.Pins())
		for name in g.Names():
			input("Press ENTER to turn on " + name )
			g.On(name)

		input("Press ENTER to turn all off")
		g.AllOff()
		'''

	except KeyboardInterrupt:
		pass

	finally:
		print("Quitting")
		g.AllOff()

