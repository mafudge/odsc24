
import time
import Adafruit_DHT

class SensorDHT11:

    pin = 23

    def __init__(self, pin =23):
        self.__pin = pin 
        self.__sensor = Adafruit_DHT.AM2302  


    def Read(self):
        temperature, humidity = None, None 
        while (temperature is None and humidity is None):
            temperature, humidity = Adafruit_DHT.read_retry(self.__sensor, self.__pin)
        return { 'am2302_temp_in_c' : temperature,  'am2302_humidity_pct' :humidity  }


if __name__ == '__main__':
    
    # setup pins
    humiture_pin = 23
    while True:
        # read from Sensors
        am2302 = SensorDHT11(humiture_pin)
        data = am2302.Read()
    
        # output data
        print("Temperature: {0:0.1f} Deg C".format(data['am2302_temp_in_c']))
        print("Humidity: {0:0.1f} %".format(data['am2302_humidity_pct']))
        
        time.sleep(1)
  