from gpiozero import LED



#yellow = LED(26, active_high=True)
#yellow.on()

tcs_white = LED(17, active_high=True)
tcs_white.off()

input("Press any key")


