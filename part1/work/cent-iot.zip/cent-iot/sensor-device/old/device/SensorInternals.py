import os

class SensorInternals:
    def CPUTemperature(self):
        res = os.popen('vcgencmd measure_temp').readline()
        return float(res.replace("temp=","").replace("'C\n",""))

    def CPUUse(self):
        return float(str(os.popen("top -n1 | awk '/Cpu\(s\):/ {print $2}'").readline().strip()))

    def ReadSensors(self):
        return self.CPUTemperature(), self.CPUUse()


if __name__=='__main__':
    sensor = SensorInternals()
    tempc, usage = sensor.ReadSensors()
    print("CPU: Temperature {0:0.1f} deg C".format(tempc))
    print("CPU: Usage {0:0.1f} Percent".format(usage))