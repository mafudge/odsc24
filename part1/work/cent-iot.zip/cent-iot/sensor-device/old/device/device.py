
'''
TODO:
- Need to read audio levels from microphone
'''

import time
import datetime 
import logging
import json 

from SensorInternals import SensorInternals
from SensorDHT11 import SensorDHT11
from SensorBMP180 import SensorBMP180
from SensorTCS34725 import SensorTCS34725
from SensorPIR import SensorPIR
from PingLED import PingLED

import paho.mqtt.client as mqtt

if __name__ == '__main__':

    try:

        THINGSBOARD_HOST = 'demo.thingsboard.io'
        ACCESS_TOKEN = 'DHT22_DEMO_TOKEN'
        INTERVAL = 3 # Every 3 seconds
        next_reading = time.time() 

        # Sensor Data 
        data = { 
            'time' : 0,
            'dht11_temp_c' : 0,
            'dht11_rel_humidity': 0,
            'bmp180_temp_c' :0,
            'bmp180_pressure_hpa' : 0,
            'bmp180_altitude_m': 0,
            'bmp180_sealevel_pressure_hpa' :0,
            'cpu_temp_c':0,
            'cpu_usage': 0,
            'tcs_color_red' : 0,
            'tcs_color_blue' : 0,
            'tcs_color_green' : 0,
            'tcs_color_clear' : 0,
            'tcs_color_temp_k' : 0,
            'tcs_bright_lux' : 0,
            'pir_motion': 0
                }

        # constructors
        logging.basicConfig(level=logging.INFO)
        pingled = PingLED(green_pin = 17, red_pin = 22)
        internals = SensorInternals()        
        dht11 = SensorDHT11(pin = 23)
        bmp180 = SensorBMP180()
        tcs = SensorTCS34725()
        pir = SensorPIR(pin = 4)

        # setup mqtt
        logging.info("CONNECTING TO: {0}".format(THINGSBOARD_HOST))
        client = mqtt.Client()
        client.username_pw_set(ACCESS_TOKEN)
        # Connect to ThingsBoard using default MQTT port and 60 seconds keepalive interval
        client.connect(THINGSBOARD_HOST, 1883, 60)
        client.loop_start()

        while True:

            # check network
            pingled.Ping(THINGSBOARD_HOST)

            # read from Sensors
            data['time'] = "{0}".format(datetime.datetime.now())
            data['dht11_temp_c'], data['dht11_rel_humidity']  = dht11.ReadSensors()
            data['cpu_temp_c'], data['cpu_usage'] = internals.ReadSensors()        
            data['bmp180_temp_c'], data['bmp180_pressure_hpa'], data['bmp180_altitude_m'], data['bmp180_sealevel_pressure_hpa'] = bmp180.ReadSensors()
            data['tcs_color_red'],data['tcs_color_blue'],data['tcs_color_green'],data['tcs_color_clear'],data['tcs_color_temp_k'],data['tcs_bright_lux'] = tcs.ReadSensors()
            data['pir_motion'] = pir.MotionDetected()

            # LOG data to Console
            logging.info("================================================")
            logging.info("TIME: {0}".format(data['time']))
            logging.info("DHT11: Temperature: {0:0.1f} deg C".format(data['dht11_temp_c']))
            logging.info("DHT11: Humidity: {0:0.1f} %".format(data['dht11_rel_humidity']))
            logging.info('BMP180: Temperature: {0:0.1f} C'.format(data['bmp180_temp_c']))
            logging.info('BMP180: Pressure: {0:0.1f} hPa'.format(data['bmp180_pressure_hpa']))
            logging.info('BMP180: Altitude: {0:0.1f} m'.format(data['bmp180_altitude_m']))
            logging.info('BMP180: Sea-Level Pressure: {0:0.1f} hPa'.format(data['bmp180_sealevel_pressure_hpa']))
            logging.info("CPU: Temperature: {0:0.1f} deg C".format(data['cpu_temp_c']))
            logging.info("CPU: Usage: {0:0.1f} ".format(data['cpu_usage']))
            logging.info("TCS: Color: red={0} green={1} blue={2} clear={3}".format(data['tcs_color_red'], data['tcs_color_blue'], data['tcs_color_green'], data['tcs_color_clear']))
            logging.info("TCS: Color Temperature: {0} K".format(0 if data['tcs_color_temp_k'] == None else data['tcs_color_temp_k'] ))
            logging.info("TCS: Luminosity: {0} lux".format(data['tcs_bright_lux']))
            logging.info("PIR: Motion Detected: {0}".format(data['pir_motion'] ))

            
            # Sending humidity and temperature data to ThingsBoard
            client.publish('v1/devices/me/telemetry', json.dumps(data), 1)

            # Is it time to poll again?
            next_reading += INTERVAL
            sleep_time = next_reading-time.time()
            if sleep_time > 0:
                time.sleep(sleep_time)
            
    except KeyboardInterrupt:
        pass 

    # Finally
    pingled.AllOff()
    client.loop_stop()
    client.disconnect()