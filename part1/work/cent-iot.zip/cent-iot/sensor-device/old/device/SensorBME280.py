import board
import digitalio
import busio
import time
import adafruit_bme280

class SensorBME280:

    i2c = busio.I2C(board.SCL, board.SDA)
    bme280 = adafruit_bme280.Adafruit_BME280_I2C(i2c)


    def __init__(self, pressure = 1014.5):


        # Create library object using our Bus I2C port
        i2c = busio.I2C(board.SCL, board.SDA)
        bme280 = adafruit_bme280.Adafruit_BME280_I2C(i2c)

        # OR create library object using our Bus SPI port
        #spi = busio.SPI(board.SCK, board.MOSI, board.MISO)
        #bme_cs = digitalio.DigitalInOut(board.D10)
        #bme280 = adafruit_bme280.Adafruit_BME280_SPI(spi, bme_cs)

        # change this to match the location's pressure (hPa) at sea level
        bme280.sea_level_pressure =  pressure



    def ReadSensors(self):
        return  {   'Temperature C' : self.bme280.temperature ,
                    #'Dew Point C' : self.bme280.dew_point,
                    'Humidity' : self.bme280.humidity,
                    'Pressure Hpa' :  self.bme280.pressure,
                    'Altitude M' : self.bme280.altitude
        }



if __name__ =='__main__':
    bme280 = SensorBME280()
    while True:
#        print("\nTemperature: %0.1f C" % bme280.temperature)
#        print("Humidity: %0.1f %%" % bme280.humidity)
#        print("Pressure: %0.1f hPa" % bme280.pressure)
#        print("Altitude = %0.2f meters" % bme280.altitude)
        print(bme280.ReadSensors())
        time.sleep(2)
