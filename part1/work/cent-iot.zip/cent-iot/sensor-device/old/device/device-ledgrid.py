import paho.mqtt.client as mqtt
import time
import json 
from LEDGrid import LEDGrid

# This is a demo of controlling the  LED Grid over MQTT


states = [ 'on', 'off', 'blink']
grid = LEDGrid(active_high=False)

# When a message comes in
def on_message(client, obj, msg):
    global states
    global grid
    print("DEBUG", msg.topic, msg.qos, msg.payload)
    led, state = msg.payload.decode('utf-8').lower().split(' ')
    if state  == 'on':
        if led in grid.Names():
            grid.On(led)
        elif led == 'all':
            grid.On()
    elif state  == 'off':
        if led in grid.Names():
            grid.Off(led)
        elif led == 'all':
            grid.Off()
    elif state  == 'blink':
        if led in grid.Names():
            grid.Blink(led)
        elif led == 'all':
            grid.Blink()


if __name__ == '__main__':

    try:

        grid.AllOff()
        MQTT_HOST = '169.254.177.61' # 'broker.hivemq.com'
        CMD_TOPIC = '/cent/iot/cmd'
        DATA_TOPIC = '/cent/iot/data'
        INTERVAL = 2 # Every 2 seconds
        counter = 0
        next_reading = time.time() 

        client = mqtt.Client()
        client.connect(MQTT_HOST, 1883, 60)
        client.on_message = on_message
        client.subscribe(CMD_TOPIC)
        client.loop_start()

        while True:

            # Send a Message
            counter +=1

            data = json.dumps(grid.LEDStatus())
            print("PUBLISH", data, "TO TOPIC", DATA_TOPIC)
            client.publish(DATA_TOPIC,data,False)

            # Is it time to poll again?
            next_reading += INTERVAL
            sleep_time = next_reading-time.time()
            if sleep_time > 0:
                time.sleep(sleep_time)
    except KeyboardInterrupt:
        pass 

    finally:
        client.loop_stop()
        client.disconnect()
        grid.AllOff()
        print(grid.LEDStatus())

