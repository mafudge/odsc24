import time
from gpiozero import MotionSensor

class SensorPIR:

    pin = 4
    pir = None

    def __init__(self, pin = 4):
        self.pir = MotionSensor(self.pin)

    def MotionDetected(self):
        return int(self.pir.motion_detected)

    

if __name__=='__main__':
    sensor = SensorPIR()
    try:
        while True:
            print("PIR: Motion:", sensor.MotionDetected())
            time.sleep(2)
    except KeyboardInterrupt:
        pass 