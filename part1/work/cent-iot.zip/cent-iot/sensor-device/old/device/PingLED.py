import os
import time
from gpiozero import LED

class PingLED:

    greenLED = None
    redLED = None 

    def __init__(self, green_pin = 17, red_pin = 22):
        self.greenLED = LED(green_pin)
        self.redLED = LED(red_pin)

    def Ping(self, hostname = None):
        if hostname == None:
            hostname = "128.230.12.5"

        response = os.system("ping -c 1 " + hostname + " > /dev/null")
        if  response == 0:  # positive responses are zero
            if self.redLED != None:
                self.redLED.off()
            if self.greenLED != None:
                self.greenLED.on()
            return True
        else:
            if self.redLED != None:
                self.redLED.on()
            if self.greenLED != None:
                self.greenLED.off()
            return False

    def AllOff(self):
        if self.redLED != None:
            self.redLED.off()
        if self.greenLED != None:
            self.greenLED.off()



if __name__=='__main__':
    p  = PingLED()
    p.AllOff()
    p.Ping("www.syr.edu")
    time.sleep(2)
    p.Ping("1.2.3.4")
    time.sleep(2)
    p.Ping("128.230.12.5")
    time.sleep(2)
    p.AllOff()
