import paho.mqtt.client as mqtt
import time
import json

data = dict() 

def on_log(client, obj, level, string):
    print(string)

def on_message(client, obj, msg):
    global data
    #print(msg.topic+" "+str(msg.qos)+" "+str(msg.payload))
    data = json.loads(msg.payload)

def print_leds(leds):
    for led in leds:
        print("%10s %s" % (led, leds[led]))

def print_bme280(bme280):
    for reading in bme280.keys():
        print("%15s %s" % (reading, bme280[reading]))

if __name__ == '__main__':

    try:

        MQTT_HOST = 'gw.bigdata.syr.edu' #'169.254.177.61' #'broker.hivemq.com'
        CMD_TOPIC = '/cent/iot/cmd'
        DATA_TOPIC = '/cent/iot/data'
        INTERVAL = 5 # Every 5 seconds
        counter = 0
        next_reading = time.time() 

        client = mqtt.Client()
        client.connect(MQTT_HOST, 1883,60)
        client.on_message = on_message
        # cut down on the noise... disable
        #client.on_log = on_log
        client.subscribe(DATA_TOPIC,2)
        client.loop_start()

        while True:

            # Send a Message
            cmd = input("ENTER COMMAND: ").lower()
            if cmd=='help':
                print('ledgrid - show status of led grid')
                print('bme280 - show readings from the BME280 sensor')
                print('led on|off|blink - set status of led to on/off/blink.')
                print()
                print("EXAMPLE: red on - turns red led on.")
            elif cmd =='ledgrid':
                print_leds(data['ledgrid'])
            elif cmd == 'bme280':
                print_bme280(data['bme280'])
            else:
                print("PUBLISH", cmd , "TO TOPIC", CMD_TOPIC)
                client.publish(CMD_TOPIC, cmd, qos=2,retain=False)

            # Is it time to poll again?
            next_reading += INTERVAL
            sleep_time = next_reading-time.time()
            if sleep_time > 0:
                time.sleep(sleep_time)

    except KeyboardInterrupt:
        pass 

    finally:
        client.loop_stop()
        client.disconnect()
