import os
import time
import sys
from sense_hat import SenseHat
import paho.mqtt.client as mqtt
import json
import random 

def c2f(c):
	return c*9/5 + 32

def wait_for_network(host):

	sense.show_message("Go")
	response = 1
	while response !=0:
        	response = os.system("ping -W 1 -c 2 " + host)
	        if response != 0:
        		sense.show_message("X", scroll_speed=0.05, text_colour=(255,0,0))        
	sense.show_message("OK")
	return 

def update_display(sense,pos):
	sense.clear()
	row = pos % 8
	col = pos // 8
	r = random.randint(0,255)
	g = random.randint(0,255)
	b = random.randint(0,255)
	sense.set_pixel(row,col,r,g,b)
	return (pos+1) % 64



if __name__=='__main__':

	THINGSBOARD_HOST = '10.30.24.19'  # WAS: demo.thingsboard.io'
	ACCESS_TOKEN = '9WBMJ1xxf9ao2fNazYQ8'
	INTERVAL = 2
	TOPIC = 'v1/devices/me/telemetry'

	sense = SenseHat()

	wait_for_network(THINGSBOARD_HOST)
	sense.clear()

	next_reading = time.time()

	client = mqtt.Client()
	client.username_pw_set(ACCESS_TOKEN)
	client.connect(THINGSBOARD_HOST, 1883, 60)

	client.loop_start()
	pos = 0
	try:
		while True:
			pos = update_display(sense,pos)
			h = sense.get_humidity()
			p = sense.get_pressure()
			t = c2f(sense.get_temperature())
			sensor_data = { 'temperature' : t, 'humidity' : h, 'pressure' : p }
			print(sensor_data)
			client.publish(TOPIC, json.dumps(sensor_data),1)		
			next_reading += INTERVAL
			sleep_time = next_reading - time.time()
			if sleep_time > 0:
	        		time.sleep(sleep_time)

	except KeyboardInterrupt:
		pass

	client.loop.stop()
	client.disconnect()



