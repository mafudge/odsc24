#!/bin/bash
/usr/bin/python3 /home/pi/living-lab-sensors/demo-rpi3sensehat/thingsboard-sensehat.py

