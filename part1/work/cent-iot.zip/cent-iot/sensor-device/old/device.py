import paho.mqtt.client as mqtt
import time
import json 
from device.LEDGrid import LEDGrid
from device.SensorBME280 import SensorBME280


# When a message comes in
def on_message(client, obj, msg):
    global led_grid
    print("DEBUG", msg.topic, msg.qos, msg.payload)
    payload = msg.payload.decode('utf-8').lower()
    led, state = payload.split(' ')
    if state  == 'on':
        led_grid.On(led)
    elif state == 'off':
        led_grid.Off(led)
    elif state == 'blink':
        led_grid.Blink(led)


if __name__ == '__main__':

    try:

        led_grid = LEDGrid(active_high=False)
        bme280 = SensorBME280()
        MQTT_HOST = '169.254.177.61' # 'broker.hivemq.com'
        CMD_TOPIC = '/cent/iot/cmd'
        DATA_TOPIC = '/cent/iot/data'
        INTERVAL = 10 # Every 5 seconds
        counter = 0
        next_reading = time.time() 

        client = mqtt.Client()
        client.connect(MQTT_HOST, 1883, 60)
        client.on_message = on_message
        client.subscribe(CMD_TOPIC)
        client.loop_start()

        while True:

            # Send a Message
            counter +=1

            data = json.dumps({ 'ledgrid' : led_grid.LEDStatus(), 'bme280' : bme280.ReadSensors() })
            print("PUBLISH", data, "TO TOPIC", DATA_TOPIC)
            client.publish(DATA_TOPIC,data,False)

            # Is it time to poll again?
            next_reading += INTERVAL
            sleep_time = next_reading-time.time()
            if sleep_time > 0:
                time.sleep(sleep_time)
    except KeyboardInterrupt:
        pass 

    finally:
        client.loop_stop()
        client.disconnect()
        led_grid.AllOff()
        led_grid.LEDStatus()
