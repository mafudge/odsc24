import abc

class LEDGridABC(abc.ABC):

    @abc.abstractmethod
    def Exists(self):
        '''
        Tests to see if the component exists
        '''
        pass

    @abc.abstractmethod
    def On(self, led = 'all'):
        '''
		Turns on the led specified or use 'all' to turn them all on
		'''
        pass

    @abc.abstractmethod
    def Off(self, led = 'all'):
        '''
		Turns off the led specified or use 'all' to turn them all off
		'''
        pass

    @abc.abstractmethod
    def Blink(self, led = 'all', on=0.5, off=0.5):
        '''
		Blinks the led specified or use 'all' to blink them all
		'''
        pass    

    @abc.abstractmethod    
    def AllOff(self):
        '''
        Turn off all LED's in the grid.
        '''
        pass

    @abc.abstractmethod    
    def Names(self):
        '''
        Returns a list of all the LED names ['white', 'red'] etc
        '''
        pass

    @abc.abstractmethod    
    def LEDs(self):
        '''
        Returns a dictionary of the actual gpiozero LED() objects, keyed by name e.g. 'red'
        '''
        pass

    @abc.abstractmethod    
    def Status(self):
        '''
        Returns a dictionary of the leds along with their current State
        '''
        pass

    @abc.abstractmethod    
    def Pins(self):
        '''
        Returns a dict of led names and their corresponding GPIO pins on the Pi
        '''
        pass

    @abc.abstractmethod    
    def ValidStates(self):
        '''
        Returns a list of possible LED states ['on', 'off','blink']
        '''
        pass

    @abc.abstractmethod    
    def Read(self):
        '''
        Returns a list of possible LED states ['on', 'off','blink']
        '''
        pass