import abc

class SensorABC(abc.ABC):

    @abc.abstractmethod
    def Exists(self):
        '''
        Tests to see if the sensor exists
        '''
        pass

    @abc.abstractmethod
    def Read(self):
        '''
        Read the sensor data, returning a dictionary.
        '''
        pass
