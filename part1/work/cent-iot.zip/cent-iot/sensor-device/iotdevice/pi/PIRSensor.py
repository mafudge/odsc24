import time
from gpiozero import MotionSensor
from iotdevice.SensorABC import SensorABC
from retrying import retry 

class PIRSensor(SensorABC):


    def __init__(self, pin = 4, queue_len = 1, threshold = 0.5):
        self.__pir = MotionSensor(pin, queue_len=queue_len, threshold= threshold)

    def Exists(self):
         return not self.__pir.closed

    @retry(stop_max_attempt_number=3,wait_exponential_multiplier=500, wait_exponential_max=4000)
    def Read(self):
        return { 
                'pir_motion_detected' : self.__pir.motion_detected #,
                #'pir_sensor_threshold' : self.__pir.threshold,
                #'pir_sensor_queue_len' : self.__pir.queue_len
                }


'''
if __name__=='__main__':
    sensor = PIRSensor(pin = 4, queue_len=1, threshold= 0.5)
    if sensor.Exists():
        try:
            while True:
                print("PIR: Motion:", sensor.Read())
                time.sleep(2)
        except KeyboardInterrupt:
            pass 
'''
