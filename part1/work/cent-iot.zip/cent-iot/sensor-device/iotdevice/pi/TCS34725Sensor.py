
# Import the TCS34725 module.
import Adafruit_TCS34725
import board
import busio
import smbus
from gpiozero import LED
from retrying import retry 

from iotdevice.SensorABC import SensorABC

class TCS34725Sensor(SensorABC):

    def __init__(self, white_led_pin = 17):
        self.__white_led_pin = white_led_pin 
        try:
            self.__setup__()
        except OSError as e:
            print(e)
            self.__exists = False

    @retry(stop_max_attempt_number=4,wait_exponential_multiplier=500, wait_exponential_max=4000)
    def __setup__(self):
         # Create a TCS34725 instance with default integration time (2.4ms) and gain (4x).
            self.tcs = Adafruit_TCS34725.TCS34725()
            self.__LED = LED(self.__white_led_pin, active_high=True)

            # You can also override the I2C device address and/or bus with parameters:
            #tcs = Adafruit_TCS34725.TCS34725(address=0x30, busnum=2)

            # Or you can change the integration time and/or gain:
            #tcs = Adafruit_TCS34725.TCS34725(integration_time=Adafruit_TCS34725.TCS34725_INTEGRATIONTIME_700MS,
            #                                 gain=Adafruit_TCS34725.TCS34725_GAIN_60X)
            # Possible integration time values:
            #  - TCS34725_INTEGRATIONTIME_2_4MS  (2.4ms, default)
            #  - TCS34725_INTEGRATIONTIME_24MS
            #  - TCS34725_INTEGRATIONTIME_50MS
            #  - TCS34725_INTEGRATIONTIME_101MS
            #  - TCS34725_INTEGRATIONTIME_154MS
            #  - TCS34725_INTEGRATIONTIME_700MS
            # Possible gain values:
            #  - TCS34725_GAIN_1X
            #  - TCS34725_GAIN_4X
            #  - TCS34725_GAIN_16X
            #  - TCS34725_GAIN_60X

            self.__exists = True

            self.LEDOff()


    def LEDOn(self):
        self.__LED.on()

    def LEDOff(self):
        self.__LED.off()

    def Exists(self):
        return self.__exists

    @retry(stop_max_attempt_number=3,wait_exponential_multiplier=1000, wait_exponential_max=2000)
    def Read(self):
        #self.__setup__()
        # Disable interrupts (can enable them by passing true, see the set_interrupt_limits function too).
        #self.tcs.set_interrupt(False)

        # Read the R, G, B, C color data.
        r, g, b, c = self.tcs.get_raw_data()

        # Calculate color temperature using utility functions.  You might also want to
        # check out the colormath library for much more complete/accurate color functions.
        color_temp = Adafruit_TCS34725.calculate_color_temperature(r, g, b)

        # Calculate lux with another utility function.
        lux = Adafruit_TCS34725.calculate_lux(r, g, b)

        # Enable interrupts and put the chip back to low power sleep/disabled.
        #self.tcs.set_interrupt(True)
        #self.tcs.disable()

        return {
            'tcs34725_color_red' : r,
            'tcs34725_color_green' : g,
            'tcs34725_color_blue' : b,
            'tcs34725_color_clear' : c,
            'tcs34725_color_temp_k' : color_temp,
            'tcs34725_luminosity_lux' : lux,

        }

'''
if __name__ == '__main__':
    from time import sleep

    sensor = TCS34725Sensor()
    if sensor.Exists():
        for i in range(100):
            color_data = sensor.Read()
            print(color_data)
            sleep(1)
    else:
        print("No Sensor Exists!")
'''