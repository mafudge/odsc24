from gpiozero import LED
from iotdevice.LEDGridABC import LEDGridABC

class LEDGrid(LEDGridABC):

	'''
	Actual LED Grid on the Pi
	'''

	default_pins = { 'red' : 5, 'white' : 6, 'blue' : 13, 'green' : 19, 'yellow' : 26 }

	def __init__(self, default_pins = default_pins, active_high=True):
		'''
		default_pins is a dictionaty of GPIO pins for each LED.
		'''
		self.__default_pins = default_pins
		self.__valid_states = [ 'on', 'off', 'blink']
		self.__leds = { 'red' : None, 'white' : None, 'blue' : None, 'green' : None, 'yellow' : None }
		self.__led_states = { 'red' : 'off', 'white' : 'off', 'blue' : 'off', 'green' : 'off', 'yellow' : 'off' }
		
		# Construct the LED's	
		for key in self.__leds.keys():
			self.__leds[key] = LED( self.__default_pins[key], active_high=active_high )
		self.AllOff()

	def Exists(self):
		'''
		Tests to see if the component exists
		'''
		return True #NOTE: No way to test this right now!!!?!?!


	def On(self, led = 'all'):
		'''
		Turns on the led specified or use 'all' to turn them all on
		'''

		if led =='all':
			for key in self.__leds.keys():
				self.__leds[key].on()
				self.__led_states[key] = 'on'
		elif led in self.__leds.keys():
			self.__leds[led].on()
			self.__led_states[led] = 'on'
		else:
			pass

	def Off(self, led = 'all'):
		'''
		Turns off the led specified or use 'all' to turn them all off
		'''
		if led == 'all':
			for key in self.__leds.keys():
				self.__leds[key].off()
				self.__led_states[key] = 'off'
		elif led in self.__leds.keys():
			self.__leds[led].off()
			self.__led_states[led] = 'off'
		else:
			pass

	def Blink(self, led = 'all', on=0.5, off=0.5):
		'''
		Blinks the led specified or use 'all' to blink them all
		'''

		if led == 'all':
			for key in self.__leds.keys():
				self.__leds[key].blink()
				self.__led_states[key] = 'blink'
		elif led in self.__leds.keys():
			self.__leds[led].blink(on_time=on, off_time=off)
			self.__led_states[led] = 'blink'
		else:
			pass

	def AllOff(self):
		'''
		Turn off all LED's in the grid.
		'''
		self.Off()


	def Names(self):
		'''
		Returns a list of all the LED names ['white', 'red'] etc
		'''
		return list(self.__leds.keys())

	def LEDs(self):
		'''
		Returns a dictionary of the actual gpiozero LED() objects, keyed by name e.g. 'red'
		'''
		return self.__leds

	def Status(self):
		'''
		Returns a dictionary of the leds along with their current State
		'''
		return self.__led_states

	def Pins(self):
		'''
		Returns a dict of led names and their corresponding GPIO pins on the Pi
		'''
		return self.__default_pins

	def ValidStates(self):
		'''
		Returns a list of possible LED states ['on', 'off','blink']
		'''
		return self.__valid_states

	def Read(self):
		'''
		Returns a list of possible LED states ['on', 'off','blink']
		'''
		data = {}
		for k in self.__led_states.keys():
			data[f'led_{k}'] = self.__led_states[k]
		return data

