
import time
import Adafruit_DHT
from iotdevice.SensorABC import SensorABC
from retrying import retry 

class AM2302Sensor(SensorABC):
    '''
    Reads the AM2302 Sensor on the PI
    '''

    def __init__(self, pin = 23):
        self.__pin = pin 
        self.__sensor = Adafruit_DHT.AM2302 
        self.__found = None   

    @retry(stop_max_attempt_number=3,wait_exponential_multiplier=500, wait_exponential_max=4000)
    def Read(self):
        temperature, humidity = None, None 
        while (temperature is None and humidity is None):
            temperature, humidity = Adafruit_DHT.read(self.__sensor, self.__pin)
        return { 'am2302_temp_in_c' : temperature,  'am2302_humidity_pct' :humidity  }

    @retry(stop_max_attempt_number=3,wait_exponential_multiplier=500, wait_exponential_max=4000)
    def Exists(self, timeout = 3):
        if self.__found == None:
            temperature, humidity = Adafruit_DHT.read_retry(self.__sensor, self.__pin, retries=3, delay_seconds=1)
            self.__found =  temperature is not None and humidity is not None

        return self.__found 
        

if __name__ == '__main__':
    
    # setup pins
    humiture_pin = 23
    # read from Sensors
    am2302 = AM2302Sensor(humiture_pin)
    exists = am2302.Exists()
    while exists:
        data = am2302.Read()
    
        # output data
        print("Temperature: {0:0.1f} Deg C".format(data['am2302_temp_in_c']))
        print("Humidity: {0:0.1f} %".format(data['am2302_humidity_pct']))
        
        time.sleep(1)
    else:
        print("AM2302 not detected!")