import board
import digitalio
import busio
import adafruit_bme280
from iotdevice.SensorABC import SensorABC
from retrying import retry 

class BME280Sensor(SensorABC):


    def __init__(self, sea_level_pressure = 1028):

        try:
            self.__setup__(sea_level_pressure)

        except ValueError as e:
            #TODO Log this error
            print(e)
            self.__exists = False

    @retry(stop_max_attempt_number=4,wait_exponential_multiplier=500, wait_exponential_max=4000)
    def __setup__(self,sea_level_pressure = 1028):
            # Create library object using our Bus I2C port
            self.i2c = busio.I2C(board.SCL, board.SDA)
            self.bme280 = adafruit_bme280.Adafruit_BME280_I2C(self.i2c)

            # OR create library object using our Bus SPI port
            #spi = busio.SPI(board.SCK, board.MOSI, board.MISO)
            #bme_cs = digitalio.DigitalInOut(board.D10)
            #bme280 = adafruit_bme280.Adafruit_BME280_SPI(spi, bme_cs)

            # change this to match the location's pressure (hPa) at sea level
            self.bme280.sea_level_pressure =  sea_level_pressure
            self.bme280.mode = adafruit_bme280.MODE_NORMAL
            self.bme280.standby_period = adafruit_bme280.STANDBY_TC_500
            #self.bme280.iir_filter = adafruit_bme280.IIR_FILTER_X16
            #self.bme280.overscan_pressure = adafruit_bme280.OVERSCAN_X16
            #self.bme280.overscan_humidity = adafruit_bme280.OVERSCAN_X1
            #self.bme280.overscan_temperature = adafruit_bme280.OVERSCAN_X2

            self.__exists = True


    @retry(stop_max_attempt_number=3,wait_exponential_multiplier=500, wait_exponential_max=4000)
    def Read(self):
        return  {   'bme280_temp_in_c' : self.bme280.temperature ,
                    'bme280_sea_level_pressure' : self.bme280.sea_level_pressure,
                    'bme280_humidity_pct' : self.bme280.humidity,
                    'bme280_pressure_in_hpa' :  self.bme280.pressure,
                    'bme280_altitude_in_m' : self.bme280.altitude
        }

    def Exists(self):
        return self.__exists

