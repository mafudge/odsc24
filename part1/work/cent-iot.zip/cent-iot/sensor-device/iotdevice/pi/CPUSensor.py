import os
import psutil 
from iotdevice.CPUSensorABC import CPUSensorABC 
from retrying import retry 

class CPUSensor(CPUSensorABC):

    def __init__(self):
        self.total_memory_in_bytes = psutil.virtual_memory().total
        

    def Exists(self):
        import platform
        return platform.machine().startswith('arm') and platform.system() == 'Linux'

    @retry(stop_max_attempt_number=3,wait_exponential_multiplier=500, wait_exponential_max=4000)
    def Read(self):
        return  { 
            'cpu_temp_in_c' : self.TemperatureInC(), 
            'cpu_pct_utilization' : self.PctUtilization(), 
            'total_memory' : self.total_memory_in_bytes, 
            'available_memory' : self.AvailableMemoryBytes()
            }

    def TemperatureInC(self):
        res = os.popen('vcgencmd measure_temp').readline()
        value = float(res.replace("temp=","").replace("'C\n",""))
        return value 
    
    def PctUtilization(self):
        value = float(str(os.popen("top -n1 | awk '/Cpu\(s\):/ {print $2}'").readline().strip()))
        return value

    def TotalMemoryBytes(self):
        return self.total_memory_in_bytes

    def AvailableMemoryBytes(self):
        return psutil.virtual_memory().available


