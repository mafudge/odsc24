import abc
from iotdevice.SensorABC import SensorABC

class CPUSensorABC(SensorABC):

    def __init(self):
        pass

    @abc.abstractmethod
    def TemperatureInC(self):
        pass

    @abc.abstractmethod
    def PctUtilization(self):
        pass

    @abc.abstractmethod
    def TotalMemoryBytes(self):
        pass

    @abc.abstractmethod
    def AvailableMemoryBytes(self):
        pass
