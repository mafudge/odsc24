import random
from iotdevice.SensorABC import SensorABC

class BME280Sensor(SensorABC):


    def __init__(self, sea_level_pressure = 1028):
        self.__sea_level_pressure = sea_level_pressure

    def Read(self):
        return  {   'bme280_temp_in_c' :random.random()*20+10,
                    'bme280_sea_level_pressure' : self.__sea_level_pressure,
                    'bme280_humidity_pct' : random.random()*20 + 20,
                    'bme280_pressure_in_hpa' :  self.__sea_level_pressure + (random.random()-0.5)*10,
                    'bme280_altitude_in_m' : 500
        }

    def Exists(self):
        return True

