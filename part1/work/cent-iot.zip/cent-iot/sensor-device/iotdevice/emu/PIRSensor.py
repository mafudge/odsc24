import random 
from iotdevice.SensorABC import SensorABC

class PIRSensor(SensorABC):


    def Exists(self):
         return True

    def Read(self):
        return { 
                'pir_motion_detected' : random.choice([False, False, False, True] )
                }

