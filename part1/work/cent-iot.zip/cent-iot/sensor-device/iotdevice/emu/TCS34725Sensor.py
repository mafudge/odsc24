
import random
from iotdevice.SensorABC import SensorABC
from retrying import retry 

class TCS34725Sensor(SensorABC):

    def LEDOn(self):
        print("[TCS34725Sensor LED On]")

    def LEDOff(self):
        print("[TCS34725Sensor LED Off]")

    def Exists(self):
        return True

    def Read(self):
        # Disable interrupts (can enable them by passing true, see the set_interrupt_limits function too).
        #self.tcs.set_interrupt(False)

        # Read the R, G, B, C color data.
        r, g, b, c = random.randint(0,255),random.randint(0,255),random.randint(0,255),random.randint(0,255) 

        # Calculate color temperature using utility functions.  You might also want to
        # check out the colormath library for much more complete/accurate color functions.
        color_temp = self.calculate_color_temperature(r, g, b)

        # Calculate lux with another utility function.
        lux = self.calculate_lux(r, g, b)

        # Enable interrupts and put the chip back to low power sleep/disabled.
        #self.tcs.set_interrupt(True)
        #self.tcs.disable()

        return {
            'tcs34725_color_red' : r,
            'tcs34725_color_green' : g,
            'tcs34725_color_blue' : b,
            'tcs34725_color_clear' : c,
            'tcs34725_color_temp_k' : color_temp,
            'tcs34725_luminosity_lux' : lux,

        }

    # Utility methods:
    def calculate_color_temperature(self,r, g, b):
        """Converts the raw R/G/B values to color temperature in degrees Kelvin."""
        # 1. Map RGB values to their XYZ counterparts.
        # Based on 6500K fluorescent, 3000K fluorescent
        # and 60W incandescent values for a wide range.
        # Note: Y = Illuminance or lux
        X = (-0.14282 * r) + (1.54924 * g) + (-0.95641 * b)
        Y = (-0.32466 * r) + (1.57837 * g) + (-0.73191 * b)
        Z = (-0.68202 * r) + (0.77073 * g) + ( 0.56332 * b)
        # Check for divide by 0 (total darkness) and return None.
        if (X + Y + Z) == 0:
            return None
        # 2. Calculate the chromaticity co-ordinates
        xc = (X) / (X + Y + Z)
        yc = (Y) / (X + Y + Z)
        # Check for divide by 0 again and return None.
        if (0.1858 - yc) == 0:
            return None
        # 3. Use McCamy's formula to determine the CCT
        n = (xc - 0.3320) / (0.1858 - yc)
        # Calculate the final CCT
        cct = (449.0 * (n ** 3.0)) + (3525.0 *(n ** 2.0)) + (6823.3 * n) + 5520.33
        return int(cct)

    def calculate_lux(self,r, g, b):
        """Converts the raw R/G/B values to luminosity in lux."""
        illuminance = (-0.32466 * r) + (1.57837 * g) + (-0.73191 * b)
        return int(illuminance)

