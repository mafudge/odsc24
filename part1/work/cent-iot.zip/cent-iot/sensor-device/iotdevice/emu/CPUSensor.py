import os
import random 
from iotdevice.CPUSensorABC import CPUSensorABC 

class CPUSensor(CPUSensorABC):
    ''' 
    Emulation of the CPU Sensor
    '''

    def __init__(self):
        pass 

    def Exists(self):
        return True 

    def Read(self):
        return  { 
            'cpu_temp_in_c' : self.TemperatureInC(), 
            'cpu_pct_utilization' : self.PctUtilization(), 
            'total_memory' : self.TotalMemoryBytes(), 
            'available_memory' : self.AvailableMemoryBytes()
            }

    def TemperatureInC(self):
        value = round(random.random()*30 + 30,1)
        return value 
    
    def PctUtilization(self):
        value = round(random.random()*15 + 1,1)
        return value
        
    def TotalMemoryBytes(self):
        value = int(random.random()*1000000)
        return value

    def AvailableMemoryBytes(self):
        value = int(random.random()*500000)
        return value


