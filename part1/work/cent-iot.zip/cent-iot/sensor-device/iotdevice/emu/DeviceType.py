from iotdevice.DeviceTypeABC import DeviceTypeABC

class DeviceType(DeviceTypeABC):

    def __init__(self):
        pass

    def Read(self) -> str:
        return "emu"

