import random 
from iotdevice.SensorABC import SensorABC

class AM2302Sensor(SensorABC):
    '''
    Emulates the AM2302 Sensor
    '''

    def __init__(self, pin =23):
        self.__pin = pin 
        self.__sensor = None 

    def Read(self):
        temperature, humidity = random.random()*20+10, random.random()*20 + 20 
        return { 'am2302_temp_in_c' : temperature,  'am2302_humidity_pct' :humidity  }

    def Exists(self, timeout = 3):
        return True 
        

