import abc 

class DeviceTypeABC(abc.ABC):

    @abc.abstractmethod
    def Read(self):
        pass
