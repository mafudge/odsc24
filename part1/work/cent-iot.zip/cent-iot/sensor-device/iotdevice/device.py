import platform
import socket
from time import sleep

class IoTDevice:
    
    def __init__(self, device_type = "detect"):

        self.machine = platform.machine().lower()
        self.system = platform.system().lower()
        self.hostname = socket.gethostname()
        self.python_version = platform.python_version()
        self.ip_address = self.__get_ipaddr__()
        
        if device_type == "detect":
            device_type = self.__autodetect()

        if device_type == 'pi':
            from iotdevice.pi import DeviceType
            from iotdevice.pi import CPUSensor
            from iotdevice.pi import LEDGrid
            from iotdevice.pi import AM2302Sensor
            from iotdevice.pi import BME280Sensor
            from iotdevice.pi import TCS34725Sensor
            from iotdevice.pi import PIRSensor

        else: # anything else is platform =='emu'
            from iotdevice.emu import DeviceType
            from iotdevice.emu import CPUSensor
            from iotdevice.emu import LEDGrid
            from iotdevice.emu import AM2302Sensor
            from iotdevice.emu import BME280Sensor
            from iotdevice.emu import TCS34725Sensor
            from iotdevice.emu import PIRSensor

        # Call the constructors for the various components
        self.DeviceType = DeviceType.DeviceType()
        self.CPUSensor = CPUSensor.CPUSensor()
        self.LEDGrid = LEDGrid.LEDGrid()
        self.AM2302Sensor = AM2302Sensor.AM2302Sensor()
        self.BME280Sensor = BME280Sensor.BME280Sensor(sea_level_pressure = 1040)
        self.TCS34725Sensor = TCS34725Sensor.TCS34725Sensor()
        self.PIRSensor = PIRSensor.PIRSensor()

    def __autodetect(self):
        '''
        Autodetects the platform
        '''
        if self.machine.startswith('arm') and self.system.startswith('linux'):
            self.detected = "pi"
        else:
            self.detected = "emu"

        return self.detected 

    def Features(self):
        '''
        Detects the features installed on the IoT device (camera, pir, etc...)
        '''
        return {
            'CPUSensor' : self.CPUSensor.Exists(),
            'AM2302Sensor' : self.AM2302Sensor.Exists(),
            'BME280Sensor' : self.BME280Sensor.Exists(),
            'TCS34725Sensor': self.TCS34725Sensor.Exists(),
            'PIRSensor' : self.PIRSensor.Exists(),
            'LEDGrid' : self.LEDGrid.Exists()
            
        }

    def __get_ipaddr__(self,remote_host='128.230.12.5'):
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect((remote_host,0))
        ip = s.getsockname()[0]
        s.close()
        return ip


    def Read(self):
        return {
            'machine' : self.machine,
            'system' : self.system,
            'hostname' : self.hostname,
            'ip_address' : self.ip_address,
            'python_version' : self.python_version,
            'platform' : self.detected
        }

    def ReadAll(self,delay_sec=.25):
        data = {}
        data.update(self.Read())
        data.update(self.CPUSensor.Read())
        data.update(self.TCS34725Sensor.Read())
        sleep(delay_sec)
        data.update(self.AM2302Sensor.Read())
        sleep(delay_sec)
        data.update(self.PIRSensor.Read())
        sleep(delay_sec)
        data.update(self.BME280Sensor.Read())
        sleep(delay_sec)
        data.update(self.LEDGrid.Read())
        return data