# iotdevice - A Python module for interacting with the CENT Living Lab IoT Device.

The CENT Living Lab IoT device has a number of sensors on it for a variety of IoT style applications. This package contains the code for the device itself as well as emulator for which you can simulate calls to sensors on the device. This allows you to program against the device's API without actually having the device itself, which is a useful way to develop applications without requiring access to the actual IoT device. 


