import random 
from time import sleep
from iotdevice import device
from retrying import retry


if __name__=='__main__':
    print("CENT IoT Device Diagnostics")
    print("===========================")
    
    print("[TESTING: Constructing Device Object...]")
    dev = device.IoTDevice()
    print()

    print("[TESTING: Device]")
    print("\tDevice.Read(): ", dev.Read())
    print("\tDeviceType.Read(): ", dev.DeviceType.Read())
    print("\tDevice.Features(): ", dev.Features())
    print()

    print("[TESTING: CPUSensor]")
    if dev.CPUSensor.Exists():
        print("\t[PASS] CPUSensor.Read(): ", dev.CPUSensor.Read())
        sleep(1)
    else:
        print("\t[SKIP] CPUSensor Does not exist.")
    print()

    print("[TESTING: AM2302Sensor]")
    if dev.AM2302Sensor.Exists():
        print("\t[PASS] AM2302Sensor.Read(): ", dev.AM2302Sensor.Read())
        sleep(1)
    else:
        print("\t[SKIP] AM2302Sensor Does not exist.")
    print()

    print("[TESTING: PIRSensor]")
    if dev.PIRSensor.Exists():
        print("\t[PASS] PIRSensor.Read(): ", dev.PIRSensor.Read())
        sleep(1)
    else:
        print("\t[SKIP] PIRSensor Does not exist.")
    print()

    print("[TESTING: TCS34725Sensor]")
    if dev.TCS34725Sensor.Exists():
        dev.TCS34725Sensor.LEDOn()
        print("\t[PASS] TCS34725Sensor.Read(): ", dev.TCS34725Sensor.Read())
        sleep(1)
        dev.TCS34725Sensor.LEDOff()
    else:
        print("\t[SKIP] TCS34725Sensor Does not exist.")
    print()
    print("[TESTING: BME280Sensor]")
    if dev.BME280Sensor.Exists():
        print("\t[PASS] BME280Sensor.Read(): ", dev.BME280Sensor.Read())
        sleep(1)
    else:
        print("\t[SKIP] BME280Sensor Does not exist.")
    print()
    print("[TESTING: LEDGrid]")
    if dev.LEDGrid.Exists():
        for led in dev.LEDGrid.Names():
            print("\t[PASS] LEDGrid.On({0}) ".format(led))
            dev.LEDGrid.On(led)
            sleep(1)            
        print("\t[PASS] LEDGrid.Off('all') ")
        dev.LEDGrid.Off()
        sleep(1)

        for led in dev.LEDGrid.Names():
            print("\t[PASS] LEDGrid.Blink({0}) ".format(led))
            dev.LEDGrid.Blink(led, on=random.random()/4, off=random.random()/4)
            sleep(1)            
        print("\t[PASS] LEDGrid.Off('all') ")
        dev.LEDGrid.Off()
        sleep(1)


    else:
        print("\t[SKIP]  LEDGrid Does not exist.")
    print()

 #   dev.TCS34725Sensor.LEDOff()


