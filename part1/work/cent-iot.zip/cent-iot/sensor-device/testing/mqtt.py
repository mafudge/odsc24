import paho.mqtt.client as paho
broker="nas.home.michaelfudge.com"
port=1883

def on_publish(client,userdata,result):             #create function for callback
    print("DEBUG: data published \n")
    pass


client1= paho.Client("python")                           #create client object
client1.on_publish = on_publish                          #assign function to callback
client1.connect(broker,port)                             #establish connection
ret= client1.publish("testing","python sent to this")    
print(ret.is_published())
client1.disconnect()