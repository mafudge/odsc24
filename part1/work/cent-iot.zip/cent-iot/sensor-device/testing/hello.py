x = 10
print("Hello")
print(x)
from iotdevice import device
dev = device.IoTDevice()
dev.LEDGrid.Blink(led='white')
x = input("Press ENTER")
dev.LEDGrid.AllOff()


