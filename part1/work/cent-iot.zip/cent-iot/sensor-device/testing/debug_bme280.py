import board
import digitalio
import busio
import time
import adafruit_bme280
from retrying import retry

@retry(stop_max_attempt_number=3,wait_exponential_multiplier=1python000, wait_exponential_max=4000)
def get_temp():

    # Create library object using our Bus I2C port
    i2c = busio.I2C(board.SCL, board.SDA, frequency=10000000)
    bme280 = adafruit_bme280.Adafruit_BME280_I2C(i2c)

    #spi = busio.SPI(board.SCK, board.MOSI, board.MISO)
    #bme_cs = digitalio.DigitalInOut(board.D10)
    #bme280 = adafruit_bme280.Adafruit_BME280_SPI(spi, bme_cs)

    # change this to match the location's pressure (hPa) at sea level
    bme280.sea_level_pressure = 1013.25

    temp =  bme280.temperature

    return temp

if __name__=='__main__':
    print(f"Current Temperature: {get_temp()}")