import paho.mqtt.client as mqtt
import paho.mqtt.subscribe as sub
import json
import os
import time
from gtts import gTTS
import vlc
from iotdevice import device
 
global_data = ""
dev = device.IoTDevice()
counter = 1
 
settings = {
    'local_host' : os.environ.get('LOCAL_HOST',"gw.bigdata.syr.edu"),
    'local_port' :  int(os.environ.get('LOCAL_PORT',1884)),
    'topic_root' : os.environ.get("TOPIC_ROOT","/edu.syr.cent/")
}
 
def on_connect(client, userdata, flags, rc):
    print(f"\tON CONNECT ==> {client._host}:{client._port} ==> {rc} {mqtt.connack_string(rc)}")

def on_subscribe(client, userdata, mid, granted_qos):
    print(f"\tON SUBSCRIBE ==> {client._host}:{client._port}")
    print(f"\t\tDATA: ==> {str(mid)}")
    print(f"\t\tQOS   ==> {granted_qos}")
    
def on_message(client, userdata, message):
    global global_data
    print(f"\tON MESSAGE ==> {client._host}:{client._port}")
    print(f"\t\tTOPIC   ==> {message.topic}")
    print(f"\t\tPAYLOAD ==> {str(message.payload)}")
    print(f"\t\tQOS     ==> {str(message.qos)}")
    global_data = message.payload.decode('utf-8')
    print(global_data)
    parse_command(global_data)
    
def speak(text):
    global counter
    filename = f'text{counter}.mp3'
    if os.path.exists(filename):
        os.remove(filename)
    tts = gTTS(text, 'en-us')
    tts.save(filename)
    p = vlc.MediaPlayer(f"{filename}")
    p.play()
    counter += 1
    
    
def parse_command(data):
    chunks = data.lower().split()
    if len(chunks) ==2:
        cmd = chunks[0]
        arg = chunks[1]
        if cmd in dev.LEDGrid.Names():
            print("LED command")
            if arg == "on":
                dev.LEDGrid.On(cmd)
            elif arg == "off":
                dev.LEDGrid.Off(cmd)
            elif arg == "blink":
                dev.LEDGrid.Blink(cmd, on=0.33, off=0.33)
            else:
                pass
        elif cmd == 'all' and arg=='off':
            print("ALL LED off command")
            dev.LEDGrid.AllOff()
        elif cmd == 'say':
            print("SPEAK command")
            speak(arg)
        
    
if __name__ == "__main__":

    subTopic = f"{settings['topic_root']}iot/cmd"

    local = mqtt.Client()
    local.on_connect = on_connect
    local.on_subscribe = on_subscribe
    local.on_message  = on_message
    
    print(f"CONNECT ==> {settings['local_host']}:{settings['local_port']}")
    speak('connecting')
    local.connect(settings['local_host'], settings['local_port'])
    print(f"SUBCRIBE ==> {subTopic}")
    local.subscribe(subTopic,qos=1)
    
    try:
        local.loop_start()
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("Disconnecting")
        local.loop_stop()
        print("Turning off LEDs")
        dev.LEDGrid.AllOff()
        print("Removing mp3 files")
        os.system('rm -f *.mp3')
    
    