import random
from retrying import retry

@retry
def pick_one():
    if random.randint(0, 10) != 1:        
        raise Exception("1 was not picked")


pick_one()