import os
import slack
import certifi
import ssl as ssl_lib
from iotdevice import device


dev = device.IoTDevice()

@slack.RTMClient.run_on(event="message")
def message(**payload):
    data = payload["data"]
    web_client = payload["web_client"]
    channel_id = data.get("channel")
    user_id = data.get("user")
    text = data.get("text")

    print(channel_id, user_id, text)
    parse_command(text)

def parse_command(data):
    chunks = data.lower().split()
    if len(chunks) ==2:
        cmd = chunks[0]
        arg = chunks[1]
        if cmd in dev.LEDGrid.Names():
            print("LED command")
            if arg == "on":
                dev.LEDGrid.On(cmd)
            elif arg == "off":                                                                                                       dev.LEDGrid.Off(cmd)
            elif arg == "blink":
                dev.LEDGrid.Blink(cmd, on=0.33, off=0.33)
            else:
                pass
        elif cmd == 'all' and arg=='off':
            print("ALL LED off command")
            dev.LEDGrid.AllOff()
        elif cmd == 'say':
            print("SPEAK command")



if __name__ == '__main__':

    token ='xoxb-373052759969-816577434052-MkBnxzOZ6h3BEDp7QHnld5x4'
    proxy = 'http://gw.bigdata.syr.edu:3128' 
    client = slack.WebClient(token=token, proxy=proxy)

    #response = client.chat_postMessage(
    #    channel='#random',
    #    text="Hello world!")
    #assert response["ok"]
    #assert response["message"]["text"] == "Hello world!"

    response = client.users_list()
    for user in response.data['members']:
        print(user['id'], user['name'])
        if user['name'] == 'iot-bot':
           bot_id = user['id']

    print(bot_id)
    print("Starting client...")
    ssl_context = ssl_lib.create_default_context(cafile=certifi.where())
    rtm_client = slack.RTMClient(token=token, ssl=ssl_context, proxy=proxy)
    rtm_client.start()
