# NFS Kubernetes Shared storage

## Prerequesites

1. setup an NFS server
2. setup `/etc/exports` file, for example: 
`/export/k8s     10.30.24.14(rw,sync,no_subtree_check,no_root_squash)`
3. Make sure there are full rights to `/export/k8s` i.e. `chmod 777`
4. You will need to make folders for each persistent storage service i.e. `/export/k8s/iot/thingsboard/cassandra_db`
5. Each Kubernetes node must have NFS client installed. test to make sure you can mount, but DO NOT MOUNT persistently.


## Storage Class

The Kubernetes storage class allows you to set "promises" for the type of storage. Confgiure one for your NFS server. Example: `nfs-subnet-10-storageclass.yml`


## The Wordpress example.

The wordpress example has the files `mysql-example.yml` and `wordpress-example.yml` you will need to execute both to bring up the wordpress website.

you will need to configure the `nfs:` section under both files to reflect the settings of your own NFS environment. NOTE: if you change the files, make new ones. i.e. `wordpress-example-cent-lab.yml`

example of this section:

```
  nfs:
    # host name or IP of your NFS server
    server: 10.30.24.19
    # Exported path of your NFS server. 
    # Make this directory on your server and make sure to chmod 777 it.
    path: "/export/k8s/test/wordpress"
    readOnly: false
```







