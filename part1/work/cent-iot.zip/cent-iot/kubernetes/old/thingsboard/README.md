https://thingsboard.io/docs/user-guide/install/kubernetes/

