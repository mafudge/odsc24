# Kubernetes Guide

## Setting Up the Dynamic NFS provisioner.

The dynamic provisioner will auto-create storage volumes based on storage class. 

contents are in `dynamic-nfs`

1. create the `storageclass.yml`
2. deploy the dynamic provisioner `deployment.yml` try to make sure the `path:` at the bottom of the file exists and has plenty of storage.
3. try the `exampleclaim.yml` to make sure it work (actually provisions storage)

## Installing thingsboard

PRE-REQUISITE: you must label ALL your nodes with `machinetype=any` 

You can follow the instructions here: [https://thingsboard.io/docs/user-guide/install/kubernetes/]
with these exceptions.

1. Use the files in the `iot/thingsboard` folder. do not download them from the internet!
2. skip the gcloud commands. those provision the storage which will be handled for you.
3. be patent when you execute the commands they need to perform docker pulls, etc. it might take a few minutes to complete.


