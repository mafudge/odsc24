# db-provisioner

The database provisioner is a system allowing an authenticated juypterhub user to create one or more databases. Once the database is created a set of credentials are returned.

## Basic Architecture 
```
+-----------+       +----------------+       +--------------------+
| Client(s) |-------| API / Registry |-------| Database Engine(s) |
+-----------+       +----------------+       +--------------------+
```

- **Database Engine** is a running instance of a Database Management System like Microsoft SQL Server, MongoDb, Redis, or PostgreSQL. 
- **API** is a running REST service which accepts commands from the client and then carries them out against the appropriate database engine. As such the API requires a set of master credentials to communicate with each database engine. A database engine is only supported when it implements the api.
- **Clients** can only execute inside Jupyter notebook and therefore have a level of trust with the API. The client is responsible for implementing authentication before using the API.
- **Registry** is a persistent data store which keeps track of installed database engines and API actions. This tracks which databases have been created by which user on which engine without the API having to query this information in real-time.

## API

### Database Engines

#### Configuration

Database engines are loaded from a configured file when the API starts. You cannot dynamically register an engine while the API is running.  The Database engine config should have the following information for each database engine:

- `name` of database engine. Must be unique for each instance. 
- `type` of database engine. These will typically match the python module implementation.
- `connection` the connection string to access the database. This should include host/ip, port, user, password and whatever else is necessary to connect to the database engine.

Example:

```
    [
        { 'name' : 'mssql1', 'type' : 'mssql', 'connection' : 'yadayada` },
        { 'name' : 'mongo1', 'type' : 'mongodb', 'connection' : 'yadayada` }
    ]
```

### API

`get_datbase_engines()`  
returns a list of registered database engines. Each database engine is a dictionary name and type (no connection is returned for security purposes).  

### Registry table

The registry table must keep user credentials so they may be returned to the client whenever they are requested.

| enginename | dbname | netid | dbuser | dbpassword | created_on |
|---|---|---|---|---|---|
| mssql1 | testing | mafudge | testing_mafudge | DS3hjf83jHZ30fcM | 1/1/2020 12:00 |
| mssql1 | demo | mafudge | demo_mafudge | D55673dhj30fdppi | 1/1/2020 12:05 |

The dbpassword should be written with reversible encryption. 

## API For Any Database Engine

For any database engine the following functions must be implemented:

`create_database(enginename, dbname, netid)`  

1. Create a database on `enginename` named `dbname`. If the database exists, fail.
2. `netid` is the client user's authenticated NetID.
2. Create a user `dbname_netid` and auto-generate a complex password. Assign the user full rights to the database.
3. Write the information to the API's registry table.
4. Return credentials to connect to the database. 

`get_database(enginename, dbname, netid)` 

1. Returns database credentials if they exist. Fail otherwise.
2. Can only be retrieved by NetID

`drop_database(enginename, dbname, netid)` 

1. Drops a database on `enginename` named `dbname`. If the database does not exists, fail.
2. `netid` is the client user's authenticated NetID.
2. Delete user `dbname_netid`.
3. Remove information to the API's registry table.
4. Return ok if works.

## Development environment

`docker-compose.yaml` file defines the go http web server and a single database service ms sql server. these are containers which run on docker.

### Managing the services

`docker-compose up -d` will bring up the services

You can then connect to sql server using the SQL server management studio on localhost port 1433 with username and password specified in the `docker-compose.yaml` file. 

You can access the go server by hitting the url http://localhost:8080 

`docker-compose ps` will show you the running services.

`docker-compose down` will shut down the running services

### Developing 

The `webapi` folder maps to the `app` folder in the container. If you make changes to the code in the `webapi` folder, to see the code run you must restart the container. There is no need to restart the database, so you can simply to this. 

`docker-compose restart webapi` to restart the webapi service only. 

### Debugging

There are two ways you can debug your code in VS code. 

1) install go on your local machine and run the webapi outside a container. If you do this I advise stopping the webapi container so that you can re-use port 8080. `docker-compose stop webapi`

2) use the container debugging tools in visual studio code. with these tools you can debug from inside the container itself. click the `><` icon in the lower left of your vscode environment to get started / learn more. 


