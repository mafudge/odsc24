import sys
import random
import string 
import os
import time
import logging
import requests
import paho.mqtt.client as mqtt
import paho.mqtt.publish as publish
import paho.mqtt.subscribe as subscribe
import json 

global_data = ""

settings = {
    'local_host' : os.environ.get('LOCAL_HOST',"gw.bigdata.syr.edu"),
    'local_port' :  int(os.environ.get('LOCAL_PORT',1884)),
    'remote_host' : os.environ.get('REMOTE_HOST',"broker.hivemq.com"),
    'remote_port' : int(os.environ.get('REMOTE_PORT',1883)),
    'topic_root' : os.environ.get("TOPIC_ROOT","/edu.syr.cent/")
}

def printSettings(settings):
    print("SETTINGS:")
    for key in settings.keys():
        print(f"\tsettings['{key}']={settings[key]}")

def randomString(stringLength=10):
    """Generate a random string of fixed length """
    letters = string.ascii_lowercase
    return ''.join(random.choice(letters) for i in range(stringLength))

def on_connect(client, userdata, flags, rc):
    print(f"\tON CONNECT ==> {client._host}:{client._port} ==> {rc} {mqtt.connack_string(rc)}")

def on_subscribe(client, userdata, mid, granted_qos):
    print(f"\tON SUBSCRIBE ==> {client._host}:{client._port}")
    print(f"\t\tDATA: ==> {str(mid)}")
    print(f"\t\tQOS   ==> {granted_qos}")
    
def on_message(client, userdata, message):
    global global_data
    print(f"\tON MESSAGE ==> {client._host}:{client._port}")
    print(f"\t\tTOPIC   ==> {message.topic}")
    print(f"\t\tPAYLOAD ==> {str(message.payload)}")
    print(f"\t\tQOS     ==> {str(message.qos)}")
    global_data = message.payload.decode('utf-8')

def on_message_local_fwd_to_remote(client, userdata, message):
    global settings
    msg = json.loads(message.payload.decode('utf-8'))
    print(f"\tON MESSAGE FROM ==> {client._host}:{client._port}")
    print(f"\t\tTOPIC    ==> {message.topic}")
    print(f"\t\tPAYLOAD  ==> {str(message.payload)}")
    print(f"\t\tDATA     ==> {str(msg)}")
    print(f"\t\tFWD      ==> {msg['fwd']}")
    print(f"\t\tQOS      ==> {str(message.qos)}")
    if msg['fwd']:
        print(f"\t\tFWD TO   ==> {settings['remote_host']}:{settings['remote_port']}")
        msg['fwd'] = False
        publish.single(message.topic,json.dumps(msg), qos=1, hostname=settings['remote_host'],port=settings['remote_port'])

def on_message_remote_fwd_to_local(client, userdata, message):
    global settings
    msg = parseMessage(message.payload.decode('utf-8'))
    print(f"\tON MESSAGE FROM ==> {client._host}:{client._port}")
    print(f"\t\tTOPIC    ==> {message.topic}")
    print(f"\t\tPAYLOAD  ==> {str(message.payload)}")
    print(f"\t\tDATA     ==> {str(msg)}")
    print(f"\t\tFWD      ==> {msg['fwd']}")
    print(f"\t\tQOS      ==> {str(message.qos)}")
    if msg['fwd']:
        print(f"\t\tFWD TO  ==> {settings['local_host']}:{settings['local_port']}")
        msg['fwd'] = False
        publish.single(message.topic,json.dumps(msg), qos=1, hostname=settings['local_host'],port=settings['local_port'])

def parseMessage(raw):
    try:
        deserialized = json.loads(raw)
    except json.decoder.JSONDecodeError:
        print("ParseMessage: COULD NOT DESERIALIZE")
        deserialized = raw

    if type(deserialized) != dict:
        msg = { 'data' : deserialized, 'fwd': False }
    elif deserialized.get('data',None)  == None:
        msg = { 'data' : deserialized, 'fwd': False }
    elif deserialized.get('fwd', False) != True:
        msg = { 'data' : deserialized.get('data',deserialized), 'fwd': False }
    else:
        msg = deserialized
    return msg

def testParseMessage():
    print(f"TESTING: ParseMessage()")
    msg = 'hi'
    print(f"\tParseMessage('{msg}') ==> " +  str(parseMessage(msg)))
    msg = json.dumps({"message" : "hi"})
    print(f"\tParseMessage('{msg}') ==> " + str(parseMessage(msg)))
    msg = json.dumps({"data": { "message" :"hi" } })
    print(f"\tParseMessage('{msg}') ==>" + str(parseMessage(msg)))
    msg = json.dumps({"data": 101, "fwd" : "Nope" })
    print(f"\tParseMessage('{msg}') ==> " + str(parseMessage(msg)))
    msg = json.dumps({"data": [101,120], "fwd" : True })
    print(f"\tParseMessage('{msg}') ==> " + str(parseMessage(msg)))

def testMqtt(settings, pubTopic, subTopic):

    print(f"TESTING MQTT: PUB topic ==> {pubTopic} SUB topic ==> {subTopic}")
    payload = randomString(20)
    local =  mqtt.Client()
    local.on_connect = on_connect
    local.on_subscribe = on_subscribe
    local.on_message  = on_message  

    remote = mqtt.Client()
    remote.on_connect = on_connect
    remote.on_subscribe = on_subscribe
    remote.on_message  = on_message  

    print(f"TESTING: CONNECT ==> {settings['local_host']}:{settings['local_port']}")
    local.connect(settings['local_host'], settings['local_port'])

    print(f"TESTING: CONNECT ==> {settings['remote_host']}:{settings['remote_port']}")
    remote.connect(settings['remote_host'], settings['remote_port'])

    # start the loops
    local.loop_start()
    remote.loop_start()

    # test local operation
    payload = "local test"
    print(f"TESTING: PUB/SUB ==> {settings['local_host']}:{settings['local_port']} PAYLOAD ==> {payload}")
    local.subscribe(subTopic,qos=1)
    local.publish(pubTopic,payload)
    # wait for messages
    time.sleep(1) 

    # test remote operation
    payload = "remote test"
    print(f"TESTING: PUB/SUB ==> {settings['remote_host']}:{settings['remote_port']} PAYLOAD ==> {payload}")
    remote.subscribe(subTopic, qos=1)
    remote.publish(pubTopic,payload)
    # wait for messages
    time.sleep(1) 


    # test forwarding local to remote
    local.on_message = on_message_local_fwd_to_remote
    remote.on_message = on_message
    payload = "local to remote"
    print(f"TESTING: FORWARDING PUB ==> {settings['local_host']}:{settings['local_port']} SUB ==> {settings['remote_host']}:{settings['remote_port']} PAYLOAD ==> {payload}")
    local.publish(pubTopic, payload)
    # wait for messages
    time.sleep(2) 

    # test forwarding local to remote
    local.on_message = on_message
    remote.on_message = on_message_remote_fwd_to_local
    payload = "remote to local"
    print(f"TESTING: FORWARDING PUB ==> {settings['remote_host']}:{settings['remote_port']} SUB ==> {settings['local_host']}:{settings['local_port']} PAYLOAD ==> {payload}")
    remote.publish(pubTopic,payload)
    # wait for messages
    time.sleep(2) 


    local.loop_stop()
    remote.loop_stop()
    local = None
    remote = None 


if __name__ == "__main__":
    printSettings(settings)
    subTopic = f"{settings['topic_root']}/#"
    pubTopic = f"{settings['topic_root']}/testing"
    testParseMessage()
    #testMqtt(settings, pubTopic, subTopic)

    local =  mqtt.Client()
    local.on_connect = on_connect
    local.on_subscribe = on_subscribe
    local.on_message  = on_message_local_fwd_to_remote  

    remote = mqtt.Client()
    remote.on_connect = on_connect
    remote.on_subscribe = on_subscribe
    remote.on_message  = on_message_remote_fwd_to_local

    print(f"CONNECT ==> {settings['local_host']}:{settings['local_port']}")
    local.connect(settings['local_host'], settings['local_port'])
    local.subscribe(subTopic,qos=1)
    print(f"CONNECT ==> {settings['remote_host']}:{settings['remote_port']}")
    remote.connect(settings['remote_host'], settings['remote_port'])
    remote.subscribe(subTopic, qos=1)
    print(f"MQTT PROXY STARTED")
    print(f"\tLOCAL    ==> {settings['local_host']}:{settings['local_port']}")
    print(f"\tREMOTE   ==> {settings['remote_host']}:{settings['remote_port']}")
    print(f"\tTOPICS   ==> {subTopic}")

    # TODO need to make it so when it comes from the other its not forwarded. Clientid perhaps??? do not forward from clientid == x??

    try:
        local.loop_start()
        remote.loop_start()
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        local.loop_stop()
        remote.loop_stop()