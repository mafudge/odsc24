# mqtt-proxy

An MQTT proxy script

Note to forward messages they must

- use topic `edu.syr.cent/#`
- be of the json format: `{ "data" : serialized-data-goes-here, "fwd" : true }` Messages no in this format will not forward.


## TODO

re-write the inout board to use this!!!
-website uses hivemq
- IoT device uses gw.bigdata.syr.edu