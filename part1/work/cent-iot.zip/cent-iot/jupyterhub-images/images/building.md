# Custom Jupyterhub Images



## Building

build the image with the same folder name.  
tag should be the date YYYMMDDr where "r" is the revision letter a-z on that day.

`docker build -t mafudge/jhub-datasci-notebook:20201209a .`

## debuggging

`docker run -it --rm --name jhub -p 8888:8888 mafudge/jhub-datasci-notebook:20201209b bash`