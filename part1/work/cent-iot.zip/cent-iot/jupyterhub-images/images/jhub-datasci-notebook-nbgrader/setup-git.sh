echo "This script will configure your JupyterHub environment. Please have the following handy:"
echo ""
echo " 1. Your GitHub Classroom Repository Url e.g. https://github.com...."
echo " 2. Your Github Username. The prompt will say: Username for 'https://github.com'"
echo " 3. Your Github Password. The prompt will say: Password for 'https://github.com'"
echo "    NOTE: YOU WILL NOT SEE THE PASSWORD CHARACTERS AS YOU TYPE THEM!"
echo ""
echo "If anything goes wrong or you mis-type something you can always run the script again."
echo ""
echo "Press ENTER / RETURN to Start the Process"
read

clear
read -p "Enter your full name (e.g. Michael Fudge): " FULL_NAME
read -p "Enter your GitHub Classroom Repository Url: " ORIGIN_URL
NETID=$(echo ${JUPYTERHUB_CLIENT_ID} | sed 's/jupyterhub-user-//g')
SU_EMAIL="${NETID}@syr.edu"
ORIGIN_NOPROTO=${ORIGIN_URL:7}
ORIGIN_REPO=${ORIGIN_NOPROTO##/*/}
ORIGIN_FOLDER=${ORIGIN_REPO%.git}
echo ""
echo "****** Variables ******"
echo "Your Name  : $FULL_NAME"
echo "NetId      : $NETID"
echo "Email      : $SU_EMAIL"
echo "Origin     : $ORIGIN_URL"
echo "Git Folder : $ORIGIN_FOLDER"
echo ""

cd ~/library
if [ ! -d  $ORIGIN_FOLDER ]
then
        git clone $ORIGIN_URL
fi
cd $ORIGIN_FOLDER
git config credential.helper store
git config --global user.name "$FULL_NAME"
git config --global user.email "$SU_EMAIL"
echo ""
echo "Testing Your Git Setup..."
echo "" >>  LICENSE
git add LICENSE
git commit -m "Testing Commit (git-config.sh)"
git push origin master
echo ""
echo "Script Complete. Your Git Configuration:"
git config -l