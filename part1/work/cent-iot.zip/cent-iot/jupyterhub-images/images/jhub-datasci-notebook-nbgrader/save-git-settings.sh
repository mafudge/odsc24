#!/bin/sh
echo "saving git settings..."
cp -vf /home/jovyan/.gitconfig /home/jovyan/library/ || true
cp -vf /home/jovyan/.git-credentials /home/jovyan/library/ || true