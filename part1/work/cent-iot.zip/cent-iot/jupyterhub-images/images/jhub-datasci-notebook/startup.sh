PULLERFILE=${PULLERFILE:-testing.txt}
LOG=/home/jovyan/.startup.log
HOME=/home/jovyan
THIS_COURSE=`echo "$COURSE" | awk '{print tolower($0)}'`
echo "::: restoring git" | tee -a $LOG
cp -vf $HOME/library/.gitconfig $HOME || true
cp -vf $HOME/library/.git-credentials $HOME || true

echo "::: pulling coursetools" | tee -a $LOG
gitpuller https://github.com/IST256/coursetools.git main $HOME/.coursetools || true

echo "::: symlinking coursetools" | tee -a $LOG
ln -sf $HOME/.coursetools /opt/conda/lib/python3.9/site-packages/coursetools || true

echo "::: puller file $PULLERFILE" | tee -a $LOG
for LINE in `curl -s "https://raw.githubusercontent.com/mafudge/nbgitpuller-files/master/$PULLERFILE?$(date +%s)"`; do
        LINEARRAY=(${LINE//;/ })
        GITURL=${LINEARRAY[0]}
        BRANCH=${LINEARRAY[1]}
        PCOURSE=${LINEARRAY[2]}
        REPO=${LINEARRAY[3]}
        TARGET=$HOME/library/$PCOURSE/$REPO

        echo "::: Puller course: $PCOURSE This course: $THIS_COURSE" | tee -a $LOG
        if [ $THIS_COURSE == $PCOURSE ]
        then
                echo "::: course match $PCOURSE" | tee -a $LOG
                echo "::: making $PCOURSE folder" | tee -a $LOG
                mkdir -p $HOME/library/$PCOURSE || true

                echo "::: Pulling ${GITURL} on branch $BRANCH for course $COURSE to path $TARGET" | tee -a $LOG
                # gitpuller ${GITURL} $BRANCH $TARGET || true
        fi
done