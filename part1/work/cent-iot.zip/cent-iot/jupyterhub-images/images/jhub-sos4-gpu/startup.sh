#!/bin/bash
HOME=/home/jovyan
GITURL=https://github.com/SciSciSummerSchool/s4_lectures
BRANCH=master
TARGET=$HOME/library/s4_lectures
if [ -d $TARGET ]
then
        gitpuller ${GITURL} $BRANCH $TARGET || true 
else
        git clone ${GITURL} $TARGET || true 
fi
exit 0