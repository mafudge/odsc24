#!/bin/sh
#echo "changing permissions on /home/jovyan" > /opt/startup.log
#sudo chmod 777 -R /home/jovyan/ || true
#sudo chown jovyan -R /home/jovyan/ || true
echo "restoring git" >> /opt/statup.log 
cp -vf /home/jovyan/library/.gitconfig /home/jovyan || true
cp -vf /home/jovyan/library/.git-credentials /home/jovyan || true
echo "making ist256 folder" >> /opt/startup.log
mkdir -p /home/jovyan/library/ist256 || true
mkdir -p /home/jovyan/library/ist387 || true
#echo "generating config for jupyter notebook, if it does not exist" >> /opt/startup.log
#echo 'n' | jupyter notebook --generate-config || true
#echo "switching NotebookNotary to :memory:, if required" >> /opt/startup.log 
#grep -qxF "c.NotebookNotary.db_file = ':memory:'" /home/jovyan/.jupyter/jupyter_notebook_config.py || echo "c.NotebookNotary.db_file = ':memory:'" >> /home/jovyan/.jupyter/jupyter_notebook_config.py || true
#sed -i "/c.NotebookNotary.db_file/d" /home/jovyan/.jupyter/jupyter_notebook_config.py
#echo "c.NotebookNotary.db_file = ':memory:'" >> /home/jovyan/.jupyter/jupyter_notebook_config.py
#echo "cloning fa20-class examples" >> /opt/startup.log
#rm -fr /home/jovyan/library/ist256/fa20-class-examples && git clone https://github.com/ist256/fa20-class-examples.git /home/jovyan/library/ist256/fa20-class-examples || true
#echo "pulling fa20-assignments" >> /opt/startup.log
#gitpuller https://github.com/ist256/fa20-assignments.git master library/ist256/fa20-assignments || true
#export PYTHONPATH=/home/jovyan/library/ist256/sp20-class-examples/include
#ln -s /home/jovyan/library/ist256/fa20-class-examples/include/ist256/ /opt/conda/lib/python3.7/site-packages/ist256


