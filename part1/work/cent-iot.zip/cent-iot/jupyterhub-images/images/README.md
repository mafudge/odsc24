# jupyterhub

this folder contains the docker image deployed as part of https://jupyterhub.ischool.syr.edu for IST256

## commands

### build
`$ docker build -t  mafudge/jhub-datasci-notebook:20210716a . `   


 - folder with Dockerfile is `jhub-datasci-notebook`
 - datetime stamp of build is 2021/07/16 a is the first build
 
### publish to dockerhub

`$ docker push  mafudge/jhub-datasci-notebook:20210716a ` 

### debug (Launch Notebook)

`$docker run --rm --name jhub -p 8888:8888 mafudge/jhub-datasci-notebook:20210716a `

### debug (Shell)

`$docker run -it --rm --name jhub -p 8888:8888 mafudge/jhub-datasci-notebook:20210716a  bash`
