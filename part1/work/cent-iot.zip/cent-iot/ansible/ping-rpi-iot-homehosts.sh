#!/bin/bash

ansible -u pi -m ping -i homehosts  rpi_iot
