# ansible

Ansible scripts for Cent IoT

Command line

one host, `rpih06`

`ansible -m ping -u pi -s rpih06`

an entire collection of hosts in my office (all should be working)

`ansible -m ping -u pi -s fudgeoffice`


Playbooks we need:

1. Reboot device
2. Apt get update / upgrade
3. update the http_proxy, https_proxy and ftp_proxy environment variables.
4. Run a python program as follows:
   a. Clone a public git repo
   b. pip install the requirements file
   c. execute the python2 or 3  program
5. Run diagnostics on the device (once you get the previous working you should be able to do this)
