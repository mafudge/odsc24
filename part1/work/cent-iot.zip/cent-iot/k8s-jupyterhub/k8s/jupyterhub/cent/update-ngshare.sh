#!/bin/bash

helm  --kubeconfig=/home/cent/.kube/cent-prod-config upgrade --cleanup-on-fail \
ngshare ngshare/ngshare \
--namespace jupyterhub \
--version=0.5.3-n008.h44632c7 \
--values ngshare.yaml