#!/bin/bash

helm --kubeconfig=/home/cent/.kube/cent-prod-config upgrade --cleanup-on-fail \
  jupyterhub jupyterhub/jupyterhub \
  --namespace  jupyterhub \
  --version=1.1.2 \
  --values cent-prod.yaml

#https://jupyterhub.github.io/helm-chart/

# install
# helm --kubeconfig=~/.kube/cent-prod-config upgrade --cleanup-on-fail \
#   --install jupyterhub jupyterhub/jupyterhub \
#   --namespace  jupyterhub \
#   --create-namespace \
#   --version=1.1.2 \
#   --values cent-prod.yaml


