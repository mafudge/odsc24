#!/bin/bash

helm --kubeconfig=/home/ubuntu/.kube/jupyterhub-prod-config \
  upgrade --cleanup-on-fail \
  jupyterhub jupyterhub/jupyterhub \
  --namespace  jupyterhub \
  --version=1.1.2 \
  --values config.yaml
