#!/bin/bash

helm --kubeconfig=/home/ubuntu/.kube/jupyterhub-prod-config \
  upgrade --cleanup-on-fail \
  soshub jupyterhub/jupyterhub \
  --namespace  soshub \
  --version=1.0.1 \
  --values sos.yaml
