#!/bin/bash

helm --kubeconfig=/home/ubuntu/.kube/cent-test-config \
upgrade --cleanup-on-fail \
jupyterhub jupyterhub/jupyterhub \
--namespace  jupyterhub \
--version=1.1.2 \
--values config.yaml
