# avhe-k8s

Rancher K8s-jupyterhub setup in the AVHE