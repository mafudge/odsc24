import paho.mqtt.client as mqtt
import logging
logging.basicConfig(level=logging.DEBUG)
host = "secure.mqtt.ischool-iot.net"
port = 8883
topic = "cmd/#"
user  = "iotcmd"
pwd = "bDgXjVnGjhLUoMGs6dqtFu3gE"


def on_connect(client, userdata, flags, rc):
    logging.info("Connected with result code "+str(rc))
    if rc == 0:
        logging.info("Connection OK")
        logging.info(f"Subscribing to {topic}")
        ret = client.subscribe(topic)        
    else:
        logging.info("Connection failed")
    #client.subscribe("$SYS/#")

def on_subscribe(client, userdata, mid, granted_qos):
    logging.info(f"Subscribed: {mid} {granted_qos}")    
    pass

def on_message(client, userdata, msg):
    data = msg.payload.decode("utf-8")
    logging.info(f"INCOMING: USERDATA: {userdata} TOPIC: {msg.topic} RESULT: {data}")
    pass 

client = mqtt.Client(client_id="sub")
client.on_connect = on_connect
client.on_message = on_message
client.on_subscribe = on_subscribe
client.username_pw_set(user, pwd)
client.tls_set()


client.connect(host,port, keepalive=15)

# Blocking call that processes network traffic, dispatches callbacks and
# handles reconnecting.
# Other loop*() functions are available that give a threaded interface and a
# manual interface.
client.loop_forever()
