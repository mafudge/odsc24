import paho.mqtt.client as paho
import logging
logging.basicConfig(level=logging.DEBUG)
host = "secure.mqtt.ischool-iot.net"
port = 8883
topic = "cmd/test"
user  = "iotadmin"
pwd = "s3BYsFNZ2yuiY5v9NLjyCwiV5"

def on_connect(client, userdata, flags, rc):
    logging.info("Connected with result code "+str(rc))
    if rc == 0:
        logging.info("Connection OK")
    else:
        logging.info("Connection failed")

def on_publish(client,userdata,result):         #create function for callback
    logging.info(f"OUTGOING: USERDATA: {userdata} TOPIC: {topic} RESULT: {result}")
    pass

client= paho.Client(client_id="pub")           
client.on_publish = on_publish
client.on_connect = on_connect                 
client.username_pw_set(user, pwd)
client.tls_set()
client.connect(host,port,keepalive=15)

client.loop_start()
while True:
    text = input("Enter the message, or q to quit: ")
    if text == "q":
        client.loop_stop()
        break
    ret= client.publish(topic,payload = text)
    logging.info(f"PUBLISH: {ret.is_published()}")


#
#0 - success, connection accepted
#1 - connection refused, bad protocol
#2 - refused, client-id error
#3 - refused, service unavailable 
#4 - refused, bad username or password
#5 - refused, not authorized